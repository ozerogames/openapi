# Org.OpenAPITools - the C# library for the Blockfrost.io ~ API Documentation

Blockfrost is an API as a service that allows users to interact with the Cardano blockchain and parts of its ecosystem.

## Tokens

After signing up on https://blockfrost.io, a `project_id` token is automatically generated for each project.
HTTP header of your request MUST include this `project_id` in order to authenticate against Blockfrost servers.

## Available networks

At the moment, you can use the following networks. Please, note that each network has its own `project_id`.

<table>
  <tr><td><b>Network</b></td><td><b>Endpoint</b></td></tr>
  <tr><td>Cardano mainnet</td><td><tt>https://cardano-mainnet.blockfrost.io/api/v0</td></tt></tr>
  <tr><td>Cardano testnet</td><td><tt>https://cardano-testnet.blockfrost.io/api/v0</tt></td></tr>
  <tr><td>InterPlanetary File System</td><td><tt>https://ipfs.blockfrost.io/api/v0</tt></td></tr>
</table>

## Concepts

* All endpoints return either a JSON object or an array.
* Data is returned in *ascending* (oldest first, newest last) order, if not stated otherwise.
  * You might use the `?order=desc` query parameter to reverse this order.
* By default, we return 100 results at a time. You have to use `?page=2` to list through the results.
* All time and timestamp related fields (except `server_time`) are in seconds of UNIX time.
* All amounts are returned in Lovelaces, where 1 ADA = 1 000 000 Lovelaces.
* Addresses, accounts and pool IDs are in Bech32 format.
* All values are case sensitive.
* All hex encoded values are lower case.
* Examples are not based on real data. Any resemblance to actual events is purely coincidental.
* We allow to upload files up to 100MB of size to IPFS. This might increase in the future.

## Errors

### HTTP Status codes

The following are HTTP status code your application might receive when reaching Blockfrost endpoints and
it should handle all of these cases.

* HTTP `400` return code is used when the request is not valid.
* HTTP `402` return code is used when the projects exceed their daily request limit.
* HTTP `403` return code is used when the request is not authenticated.
* HTTP `404` return code is used when the resource doesn't exist.
* HTTP `418` return code is used when the user has been auto-banned for flooding too much after previously receiving error code `402` or `429`.
* HTTP `425` return code is used when the user has submitted a transaction when the mempool is already full, not accepting new txs straight away.
* HTTP `429` return code is used when the user has sent too many requests in a given amount of time and therefore has been rate-limited.
* HTTP `500` return code is used when our endpoints are having a problem.

### Error codes

An internal error code number is used for better indication of the error in question. It is passed using the following payload.

```json
{
  \"status_code\": 403,
  \"error\": \"Forbidden\",
  \"message\": \"Invalid project token.\"
}
```
## Limits

There are two types of limits we are enforcing:

The first depends on your plan and is the number of request we allow per day. We defined the day from midnight to midnight of UTC time.

The second is rate limiting. We limit an end user, distinguished by IP address, to 10 requests per second. On top of that, we allow
each user to send burst of 500 requests, which cools off at rate of 10 requests per second. In essence, a user is allowed to make another
whole burst after (currently) 500/10 = 50 seconds. E.g. if a user attemtps to make a call 3 seconds after whole burst, 30 requests will be processed.
We believe this should be sufficient for most of the use cases. If it is not and you have a specific use case, please get in touch with us, and
we will make sure to take it into account as much as we can.

## SDKs

We support a number of SDKs that will help you in developing your application on top of Blockfrost.

<table>
  <tr><td><b>Programming language</b></td><td><b>SDK</b></td></tr>
  <tr><td>JavaScript</td><td><a href=\"https://github.com/blockfrost/blockfrost-js\">blockfrost-js</a></tr>
  <tr><td>Haskell</td><td><a href=\"https://github.com/blockfrost/blockfrost-haskell\">blockfrost-haskell</a></tr>
  <tr><td>Python</td><td><a href=\"https://github.com/blockfrost/blockfrost-python\">blockfrost-python</a></tr>
  <tr><td>Rust</td><td><a href=\"https://github.com/blockfrost/blockfrost-rust\">blockfrost-rust</a></tr>
  <tr><td>Golang</td><td><a href=\"https://github.com/blockfrost/blockfrost-go\">blockfrost-go</a></tr>
  <tr><td>Ruby</td><td><a href=\"https://github.com/blockfrost/blockfrost-ruby\">blockfrost-ruby</a></tr>
  <tr><td>Java</td><td><a href=\"https://github.com/blockfrost/blockfrost-java\">blockfrost-java</a></tr>
  <tr><td>Scala</td><td><a href=\"https://github.com/blockfrost/blockfrost-scala\">blockfrost-scala</a></tr>
  <tr><td>Swift</td><td><a href=\"https://github.com/blockfrost/blockfrost-swift\">blockfrost-swift</a></tr>
  <tr><td>Kotlin</td><td><a href=\"https://github.com/blockfrost/blockfrost-kotlin\">blockfrost-kotlin</a></tr>
  <tr><td>Elixir</td><td><a href=\"https://github.com/blockfrost/blockfrost-elixir\">blockfrost-elixir</a></tr>
  <tr><td>.NET</td><td><a href=\"https://github.com/blockfrost/blockfrost-dotnet\">blockfrost-dotnet</a></tr>
  <tr><td>Arduino</td><td><a href=\"https://github.com/blockfrost/blockfrost-arduino\">blockfrost-arduino</a></tr>
</table>


This C# SDK is automatically generated by the [OpenAPI Generator](https://openapi-generator.tech) project:

- API version: 0.1.36
- SDK version: 1.0.0
- Build package: org.openapitools.codegen.languages.CSharpNetCoreClientCodegen
    For more information, please visit [https://blockfrost.io](https://blockfrost.io)

<a name="frameworks-supported"></a>
## Frameworks supported
- .NET Core >=1.0
- .NET Framework >=4.6
- Mono/Xamarin >=vNext

<a name="dependencies"></a>
## Dependencies

- [Json.NET](https://www.nuget.org/packages/Newtonsoft.Json/) - 12.0.3 or later
- [JsonSubTypes](https://www.nuget.org/packages/JsonSubTypes/) - 1.8.0 or later
- [System.ComponentModel.Annotations](https://www.nuget.org/packages/System.ComponentModel.Annotations) - 5.0.0 or later

The DLLs included in the package may not be the latest version. We recommend using [NuGet](https://docs.nuget.org/consume/installing-nuget) to obtain the latest version of the packages:
```
Install-Package Newtonsoft.Json
Install-Package JsonSubTypes
Install-Package System.ComponentModel.Annotations
```
<a name="installation"></a>
## Installation
Generate the DLL using your preferred tool (e.g. `dotnet build`)

Then include the DLL (under the `bin` folder) in the C# project, and use the namespaces:
```csharp
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;
```
<a name="usage"></a>
## Usage

To use the API client with a HTTP proxy, setup a `System.Net.WebProxy`
```csharp
Configuration c = new Configuration();
System.Net.WebProxy webProxy = new System.Net.WebProxy("http://myProxyUrl:80/");
webProxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
c.Proxy = webProxy;
```

### Connections
Each ApiClass (properly the ApiClient inside it) will create an instance of HttpClient. It will use that for the entire lifecycle and dispose it when called the Dispose method.

To better manager the connections it's a common practice to reuse the HttpClient and HttpClientHandler (see [here](https://docs.microsoft.com/en-us/dotnet/architecture/microservices/implement-resilient-applications/use-httpclientfactory-to-implement-resilient-http-requests#issues-with-the-original-httpclient-class-available-in-net) for details). To use your own HttpClient instance just pass it to the ApiClass constructor.

```csharp
HttpClientHandler yourHandler = new HttpClientHandler();
HttpClient yourHttpClient = new HttpClient(yourHandler);
var api = new YourApiClass(yourHttpClient, yourHandler);
```

If you want to use an HttpClient and don't have access to the handler, for example in a DI context in Asp.net Core when using IHttpClientFactory.

```csharp
HttpClient yourHttpClient = new HttpClient();
var api = new YourApiClass(yourHttpClient);
```
You'll loose some configuration settings, the features affected are: Setting and Retrieving Cookies, Client Certificates, Proxy settings. You need to either manually handle those in your setup of the HttpClient or they won't be available.

Here an example of DI setup in a sample web project:

```csharp
services.AddHttpClient<YourApiClass>(httpClient =>
   new PetApi(httpClient));
```


<a name="getting-started"></a>
## Getting Started

```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class Example
    {
        public static void Main()
        {

            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.ApiKey.Add("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.ApiKeyPrefix.Add("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAccountsApi(httpClient, config, httpClientHandler);
            var stakeAddress = stake1u9ylzsgxaa6xctf4juup682ar3juj85n8tx3hthnljg47zctvm3rc;  // string | Bech32 stake address.
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Assets associated with the account addresses
                List<Object> result = apiInstance.AccountsStakeAddressAddressesAssetsGet(stakeAddress, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException e)
            {
                Debug.Print("Exception when calling CardanoAccountsApi.AccountsStakeAddressAddressesAssetsGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }

        }
    }
}
```

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *https://cardano-mainnet.blockfrost.io/api/v0*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*CardanoAccountsApi* | [**AccountsStakeAddressAddressesAssetsGet**](docs/CardanoAccountsApi.md#accountsstakeaddressaddressesassetsget) | **GET** /accounts/{stake_address}/addresses/assets | Assets associated with the account addresses
*CardanoAccountsApi* | [**AccountsStakeAddressAddressesGet**](docs/CardanoAccountsApi.md#accountsstakeaddressaddressesget) | **GET** /accounts/{stake_address}/addresses | Account associated addresses
*CardanoAccountsApi* | [**AccountsStakeAddressAddressesTotalGet**](docs/CardanoAccountsApi.md#accountsstakeaddressaddressestotalget) | **GET** /accounts/{stake_address}/addresses/total | Detailed information about account associated addresses
*CardanoAccountsApi* | [**AccountsStakeAddressDelegationsGet**](docs/CardanoAccountsApi.md#accountsstakeaddressdelegationsget) | **GET** /accounts/{stake_address}/delegations | Account delegation history
*CardanoAccountsApi* | [**AccountsStakeAddressGet**](docs/CardanoAccountsApi.md#accountsstakeaddressget) | **GET** /accounts/{stake_address} | Specific account address
*CardanoAccountsApi* | [**AccountsStakeAddressHistoryGet**](docs/CardanoAccountsApi.md#accountsstakeaddresshistoryget) | **GET** /accounts/{stake_address}/history | Account history
*CardanoAccountsApi* | [**AccountsStakeAddressMirsGet**](docs/CardanoAccountsApi.md#accountsstakeaddressmirsget) | **GET** /accounts/{stake_address}/mirs | Account MIR history
*CardanoAccountsApi* | [**AccountsStakeAddressRegistrationsGet**](docs/CardanoAccountsApi.md#accountsstakeaddressregistrationsget) | **GET** /accounts/{stake_address}/registrations | Account registration history
*CardanoAccountsApi* | [**AccountsStakeAddressRewardsGet**](docs/CardanoAccountsApi.md#accountsstakeaddressrewardsget) | **GET** /accounts/{stake_address}/rewards | Account reward history
*CardanoAccountsApi* | [**AccountsStakeAddressWithdrawalsGet**](docs/CardanoAccountsApi.md#accountsstakeaddresswithdrawalsget) | **GET** /accounts/{stake_address}/withdrawals | Account withdrawal history
*CardanoAddressesApi* | [**AddressesAddressExtendedGet**](docs/CardanoAddressesApi.md#addressesaddressextendedget) | **GET** /addresses/{address}/extended | Extended information of a specific address
*CardanoAddressesApi* | [**AddressesAddressGet**](docs/CardanoAddressesApi.md#addressesaddressget) | **GET** /addresses/{address} | Specific address
*CardanoAddressesApi* | [**AddressesAddressTotalGet**](docs/CardanoAddressesApi.md#addressesaddresstotalget) | **GET** /addresses/{address}/total | Address details
*CardanoAddressesApi* | [**AddressesAddressTransactionsGet**](docs/CardanoAddressesApi.md#addressesaddresstransactionsget) | **GET** /addresses/{address}/transactions | Address transactions
*CardanoAddressesApi* | [**AddressesAddressTxsGet**](docs/CardanoAddressesApi.md#addressesaddresstxsget) | **GET** /addresses/{address}/txs | Address transactions
*CardanoAddressesApi* | [**AddressesAddressUtxosAssetGet**](docs/CardanoAddressesApi.md#addressesaddressutxosassetget) | **GET** /addresses/{address}/utxos/{asset} | Address UTXOs of a given asset
*CardanoAddressesApi* | [**AddressesAddressUtxosGet**](docs/CardanoAddressesApi.md#addressesaddressutxosget) | **GET** /addresses/{address}/utxos | Address UTXOs
*CardanoAssetsApi* | [**AssetsAssetAddressesGet**](docs/CardanoAssetsApi.md#assetsassetaddressesget) | **GET** /assets/{asset}/addresses | Asset addresses
*CardanoAssetsApi* | [**AssetsAssetGet**](docs/CardanoAssetsApi.md#assetsassetget) | **GET** /assets/{asset} | Specific asset
*CardanoAssetsApi* | [**AssetsAssetHistoryGet**](docs/CardanoAssetsApi.md#assetsassethistoryget) | **GET** /assets/{asset}/history | Asset history
*CardanoAssetsApi* | [**AssetsAssetTransactionsGet**](docs/CardanoAssetsApi.md#assetsassettransactionsget) | **GET** /assets/{asset}/transactions | Asset transactions
*CardanoAssetsApi* | [**AssetsAssetTxsGet**](docs/CardanoAssetsApi.md#assetsassettxsget) | **GET** /assets/{asset}/txs | Asset transactions
*CardanoAssetsApi* | [**AssetsGet**](docs/CardanoAssetsApi.md#assetsget) | **GET** /assets | Assets
*CardanoAssetsApi* | [**AssetsPolicyPolicyIdGet**](docs/CardanoAssetsApi.md#assetspolicypolicyidget) | **GET** /assets/policy/{policy_id} | Assets of a specific policy
*CardanoBlocksApi* | [**BlocksEpochEpochNumberSlotSlotNumberGet**](docs/CardanoBlocksApi.md#blocksepochepochnumberslotslotnumberget) | **GET** /blocks/epoch/{epoch_number}/slot/{slot_number} | Specific block in a slot in an epoch
*CardanoBlocksApi* | [**BlocksHashOrNumberAddressesGet**](docs/CardanoBlocksApi.md#blockshashornumberaddressesget) | **GET** /blocks/{hash_or_number}/addresses | Addresses affected in a specific block
*CardanoBlocksApi* | [**BlocksHashOrNumberGet**](docs/CardanoBlocksApi.md#blockshashornumberget) | **GET** /blocks/{hash_or_number} | Specific block
*CardanoBlocksApi* | [**BlocksHashOrNumberNextGet**](docs/CardanoBlocksApi.md#blockshashornumbernextget) | **GET** /blocks/{hash_or_number}/next | Listing of next blocks
*CardanoBlocksApi* | [**BlocksHashOrNumberPreviousGet**](docs/CardanoBlocksApi.md#blockshashornumberpreviousget) | **GET** /blocks/{hash_or_number}/previous | Listing of previous blocks
*CardanoBlocksApi* | [**BlocksHashOrNumberTxsGet**](docs/CardanoBlocksApi.md#blockshashornumbertxsget) | **GET** /blocks/{hash_or_number}/txs | Block transactions
*CardanoBlocksApi* | [**BlocksLatestGet**](docs/CardanoBlocksApi.md#blockslatestget) | **GET** /blocks/latest | Latest block
*CardanoBlocksApi* | [**BlocksLatestTxsGet**](docs/CardanoBlocksApi.md#blockslatesttxsget) | **GET** /blocks/latest/txs | Latest block transactions
*CardanoBlocksApi* | [**BlocksSlotSlotNumberGet**](docs/CardanoBlocksApi.md#blocksslotslotnumberget) | **GET** /blocks/slot/{slot_number} | Specific block in a slot
*CardanoEpochsApi* | [**EpochsLatestGet**](docs/CardanoEpochsApi.md#epochslatestget) | **GET** /epochs/latest | Latest epoch
*CardanoEpochsApi* | [**EpochsLatestParametersGet**](docs/CardanoEpochsApi.md#epochslatestparametersget) | **GET** /epochs/latest/parameters | Latest epoch protocol parameters
*CardanoEpochsApi* | [**EpochsNumberBlocksGet**](docs/CardanoEpochsApi.md#epochsnumberblocksget) | **GET** /epochs/{number}/blocks | Block distribution
*CardanoEpochsApi* | [**EpochsNumberBlocksPoolIdGet**](docs/CardanoEpochsApi.md#epochsnumberblockspoolidget) | **GET** /epochs/{number}/blocks/{pool_id} | Block distribution by pool
*CardanoEpochsApi* | [**EpochsNumberGet**](docs/CardanoEpochsApi.md#epochsnumberget) | **GET** /epochs/{number} | Specific epoch
*CardanoEpochsApi* | [**EpochsNumberNextGet**](docs/CardanoEpochsApi.md#epochsnumbernextget) | **GET** /epochs/{number}/next | Listing of next epochs
*CardanoEpochsApi* | [**EpochsNumberParametersGet**](docs/CardanoEpochsApi.md#epochsnumberparametersget) | **GET** /epochs/{number}/parameters | Protocol parameters
*CardanoEpochsApi* | [**EpochsNumberPreviousGet**](docs/CardanoEpochsApi.md#epochsnumberpreviousget) | **GET** /epochs/{number}/previous | Listing of previous epochs
*CardanoEpochsApi* | [**EpochsNumberStakesGet**](docs/CardanoEpochsApi.md#epochsnumberstakesget) | **GET** /epochs/{number}/stakes | Stake distribution
*CardanoEpochsApi* | [**EpochsNumberStakesPoolIdGet**](docs/CardanoEpochsApi.md#epochsnumberstakespoolidget) | **GET** /epochs/{number}/stakes/{pool_id} | Stake distribution by pool
*CardanoLedgerApi* | [**GenesisGet**](docs/CardanoLedgerApi.md#genesisget) | **GET** /genesis | Blockchain genesis
*CardanoMetadataApi* | [**MetadataTxsLabelsGet**](docs/CardanoMetadataApi.md#metadatatxslabelsget) | **GET** /metadata/txs/labels | Transaction metadata labels
*CardanoMetadataApi* | [**MetadataTxsLabelsLabelCborGet**](docs/CardanoMetadataApi.md#metadatatxslabelslabelcborget) | **GET** /metadata/txs/labels/{label}/cbor | Transaction metadata content in CBOR
*CardanoMetadataApi* | [**MetadataTxsLabelsLabelGet**](docs/CardanoMetadataApi.md#metadatatxslabelslabelget) | **GET** /metadata/txs/labels/{label} | Transaction metadata content in JSON
*CardanoNetworkApi* | [**NetworkGet**](docs/CardanoNetworkApi.md#networkget) | **GET** /network | Network information
*CardanoPoolsApi* | [**PoolsExtendedGet**](docs/CardanoPoolsApi.md#poolsextendedget) | **GET** /pools/extended | List of stake pools with additional information
*CardanoPoolsApi* | [**PoolsGet**](docs/CardanoPoolsApi.md#poolsget) | **GET** /pools | List of stake pools
*CardanoPoolsApi* | [**PoolsPoolIdBlocksGet**](docs/CardanoPoolsApi.md#poolspoolidblocksget) | **GET** /pools/{pool_id}/blocks | Stake pool blocks
*CardanoPoolsApi* | [**PoolsPoolIdDelegatorsGet**](docs/CardanoPoolsApi.md#poolspooliddelegatorsget) | **GET** /pools/{pool_id}/delegators | Stake pool delegators
*CardanoPoolsApi* | [**PoolsPoolIdGet**](docs/CardanoPoolsApi.md#poolspoolidget) | **GET** /pools/{pool_id} | Specific stake pool
*CardanoPoolsApi* | [**PoolsPoolIdHistoryGet**](docs/CardanoPoolsApi.md#poolspoolidhistoryget) | **GET** /pools/{pool_id}/history | Stake pool history
*CardanoPoolsApi* | [**PoolsPoolIdMetadataGet**](docs/CardanoPoolsApi.md#poolspoolidmetadataget) | **GET** /pools/{pool_id}/metadata | Stake pool metadata
*CardanoPoolsApi* | [**PoolsPoolIdRelaysGet**](docs/CardanoPoolsApi.md#poolspoolidrelaysget) | **GET** /pools/{pool_id}/relays | Stake pool relays
*CardanoPoolsApi* | [**PoolsPoolIdUpdatesGet**](docs/CardanoPoolsApi.md#poolspoolidupdatesget) | **GET** /pools/{pool_id}/updates | Stake pool updates
*CardanoPoolsApi* | [**PoolsRetiredGet**](docs/CardanoPoolsApi.md#poolsretiredget) | **GET** /pools/retired | List of retired stake pools
*CardanoPoolsApi* | [**PoolsRetiringGet**](docs/CardanoPoolsApi.md#poolsretiringget) | **GET** /pools/retiring | List of retiring stake pools
*CardanoScriptsApi* | [**ScriptsDatumDatumHashGet**](docs/CardanoScriptsApi.md#scriptsdatumdatumhashget) | **GET** /scripts/datum/{datum_hash} | Datum value
*CardanoScriptsApi* | [**ScriptsGet**](docs/CardanoScriptsApi.md#scriptsget) | **GET** /scripts | Scripts
*CardanoScriptsApi* | [**ScriptsScriptHashCborGet**](docs/CardanoScriptsApi.md#scriptsscripthashcborget) | **GET** /scripts/{script_hash}/cbor | Script CBOR
*CardanoScriptsApi* | [**ScriptsScriptHashGet**](docs/CardanoScriptsApi.md#scriptsscripthashget) | **GET** /scripts/{script_hash} | Specific script
*CardanoScriptsApi* | [**ScriptsScriptHashJsonGet**](docs/CardanoScriptsApi.md#scriptsscripthashjsonget) | **GET** /scripts/{script_hash}/json | Script JSON
*CardanoScriptsApi* | [**ScriptsScriptHashRedeemersGet**](docs/CardanoScriptsApi.md#scriptsscripthashredeemersget) | **GET** /scripts/{script_hash}/redeemers | Redeemers of a specific script
*CardanoTransactionsApi* | [**TxSubmitPost**](docs/CardanoTransactionsApi.md#txsubmitpost) | **POST** /tx/submit | Submit a transaction
*CardanoTransactionsApi* | [**TxsHashDelegationsGet**](docs/CardanoTransactionsApi.md#txshashdelegationsget) | **GET** /txs/{hash}/delegations | Transaction delegation certificates
*CardanoTransactionsApi* | [**TxsHashGet**](docs/CardanoTransactionsApi.md#txshashget) | **GET** /txs/{hash} | Specific transaction
*CardanoTransactionsApi* | [**TxsHashMetadataCborGet**](docs/CardanoTransactionsApi.md#txshashmetadatacborget) | **GET** /txs/{hash}/metadata/cbor | Transaction metadata in CBOR
*CardanoTransactionsApi* | [**TxsHashMetadataGet**](docs/CardanoTransactionsApi.md#txshashmetadataget) | **GET** /txs/{hash}/metadata | Transaction metadata
*CardanoTransactionsApi* | [**TxsHashMirsGet**](docs/CardanoTransactionsApi.md#txshashmirsget) | **GET** /txs/{hash}/mirs | Transaction MIRs
*CardanoTransactionsApi* | [**TxsHashPoolRetiresGet**](docs/CardanoTransactionsApi.md#txshashpoolretiresget) | **GET** /txs/{hash}/pool_retires | Transaction stake pool retirement certificates
*CardanoTransactionsApi* | [**TxsHashPoolUpdatesGet**](docs/CardanoTransactionsApi.md#txshashpoolupdatesget) | **GET** /txs/{hash}/pool_updates | Transaction stake pool registration and update certificates
*CardanoTransactionsApi* | [**TxsHashRedeemersGet**](docs/CardanoTransactionsApi.md#txshashredeemersget) | **GET** /txs/{hash}/redeemers | Transaction redeemers
*CardanoTransactionsApi* | [**TxsHashStakesGet**](docs/CardanoTransactionsApi.md#txshashstakesget) | **GET** /txs/{hash}/stakes | Transaction stake addresses certificates
*CardanoTransactionsApi* | [**TxsHashUtxosGet**](docs/CardanoTransactionsApi.md#txshashutxosget) | **GET** /txs/{hash}/utxos | Transaction UTXOs
*CardanoTransactionsApi* | [**TxsHashWithdrawalsGet**](docs/CardanoTransactionsApi.md#txshashwithdrawalsget) | **GET** /txs/{hash}/withdrawals | Transaction withdrawal
*CardanoUtilitiesApi* | [**UtilsAddressesXpubXpubRoleIndexGet**](docs/CardanoUtilitiesApi.md#utilsaddressesxpubxpubroleindexget) | **GET** /utils/addresses/xpub/{xpub}/{role}/{index} | Derive an address
*HealthApi* | [**HealthClockGet**](docs/HealthApi.md#healthclockget) | **GET** /health/clock | Current backend time
*HealthApi* | [**HealthGet**](docs/HealthApi.md#healthget) | **GET** /health | Backend health status
*HealthApi* | [**RootGet**](docs/HealthApi.md#rootget) | **GET** / | Root endpoint
*IPFSAddApi* | [**IpfsAddPost**](docs/IPFSAddApi.md#ipfsaddpost) | **POST** /ipfs/add | Add a file to IPFS
*IPFSGatewayApi* | [**IpfsGatewayIPFSPathGet**](docs/IPFSGatewayApi.md#ipfsgatewayipfspathget) | **GET** /ipfs/gateway/{IPFS_path} | Relay to an IPFS gateway
*IPFSPinsApi* | [**IpfsPinAddIPFSPathPost**](docs/IPFSPinsApi.md#ipfspinaddipfspathpost) | **POST** /ipfs/pin/add/{IPFS_path} | Pin an object
*IPFSPinsApi* | [**IpfsPinListGet**](docs/IPFSPinsApi.md#ipfspinlistget) | **GET** /ipfs/pin/list | List pinned objects
*IPFSPinsApi* | [**IpfsPinListIPFSPathGet**](docs/IPFSPinsApi.md#ipfspinlistipfspathget) | **GET** /ipfs/pin/list/{IPFS_path} | Get details about pinned object
*IPFSPinsApi* | [**IpfsPinRemoveIPFSPathPost**](docs/IPFSPinsApi.md#ipfspinremoveipfspathpost) | **POST** /ipfs/pin/remove/{IPFS_path} | 
*MetricsApi* | [**MetricsEndpointsGet**](docs/MetricsApi.md#metricsendpointsget) | **GET** /metrics/endpoints | Blockfrost endpoint usage metrics
*MetricsApi* | [**MetricsGet**](docs/MetricsApi.md#metricsget) | **GET** /metrics/ | Blockfrost usage metrics
*NutLinkApi* | [**NutlinkAddressGet**](docs/NutLinkApi.md#nutlinkaddressget) | **GET** /nutlink/{address} | 
*NutLinkApi* | [**NutlinkAddressTickersGet**](docs/NutLinkApi.md#nutlinkaddresstickersget) | **GET** /nutlink/{address}/tickers | 
*NutLinkApi* | [**NutlinkAddressTickersTickerGet**](docs/NutLinkApi.md#nutlinkaddresstickerstickerget) | **GET** /nutlink/{address}/tickers/{ticker} | 
*NutLinkApi* | [**NutlinkTickersTickerGet**](docs/NutLinkApi.md#nutlinktickerstickerget) | **GET** /nutlink/tickers/{ticker} | 


<a name="documentation-for-models"></a>
## Documentation for Models

 - [Model.AccountAddressesTotal](docs/AccountAddressesTotal.md)
 - [Model.AccountAddressesTotalReceivedSum](docs/AccountAddressesTotalReceivedSum.md)
 - [Model.AccountContent](docs/AccountContent.md)
 - [Model.AddressContent](docs/AddressContent.md)
 - [Model.AddressContentExtended](docs/AddressContentExtended.md)
 - [Model.AddressContentExtendedAmount](docs/AddressContentExtendedAmount.md)
 - [Model.AddressContentTotal](docs/AddressContentTotal.md)
 - [Model.Asset](docs/Asset.md)
 - [Model.AssetMetadata](docs/AssetMetadata.md)
 - [Model.BlockContent](docs/BlockContent.md)
 - [Model.EpochContent](docs/EpochContent.md)
 - [Model.EpochParamContent](docs/EpochParamContent.md)
 - [Model.GenesisContent](docs/GenesisContent.md)
 - [Model.InlineResponse200](docs/InlineResponse200.md)
 - [Model.InlineResponse2001](docs/InlineResponse2001.md)
 - [Model.InlineResponse2002](docs/InlineResponse2002.md)
 - [Model.InlineResponse2003](docs/InlineResponse2003.md)
 - [Model.InlineResponse2004](docs/InlineResponse2004.md)
 - [Model.InlineResponse2005](docs/InlineResponse2005.md)
 - [Model.InlineResponse2006](docs/InlineResponse2006.md)
 - [Model.InlineResponse2007](docs/InlineResponse2007.md)
 - [Model.InlineResponse400](docs/InlineResponse400.md)
 - [Model.InlineResponse403](docs/InlineResponse403.md)
 - [Model.InlineResponse404](docs/InlineResponse404.md)
 - [Model.InlineResponse418](docs/InlineResponse418.md)
 - [Model.InlineResponse425](docs/InlineResponse425.md)
 - [Model.InlineResponse429](docs/InlineResponse429.md)
 - [Model.InlineResponse500](docs/InlineResponse500.md)
 - [Model.Network](docs/Network.md)
 - [Model.NetworkStake](docs/NetworkStake.md)
 - [Model.NetworkSupply](docs/NetworkSupply.md)
 - [Model.NutlinkAddress](docs/NutlinkAddress.md)
 - [Model.Pool](docs/Pool.md)
 - [Model.PoolMetadata](docs/PoolMetadata.md)
 - [Model.Script](docs/Script.md)
 - [Model.ScriptCbor](docs/ScriptCbor.md)
 - [Model.ScriptDatum](docs/ScriptDatum.md)
 - [Model.ScriptJson](docs/ScriptJson.md)
 - [Model.TxContent](docs/TxContent.md)
 - [Model.TxContentOutputAmount](docs/TxContentOutputAmount.md)
 - [Model.TxContentUtxo](docs/TxContentUtxo.md)
 - [Model.TxContentUtxoInputs](docs/TxContentUtxoInputs.md)
 - [Model.TxContentUtxoOutputs](docs/TxContentUtxoOutputs.md)
 - [Model.UtilsAddressesXpub](docs/UtilsAddressesXpub.md)


<a name="documentation-for-authorization"></a>
## Documentation for Authorization

<a name="ApiKeyAuth"></a>
### ApiKeyAuth

- **Type**: API key
- **API key parameter name**: project_id
- **Location**: HTTP header

