/*
 * Blockfrost.io ~ API Documentation
 *
 * Blockfrost is an API as a service that allows users to interact with the Cardano blockchain and parts of its ecosystem.  ## Tokens  After signing up on https://blockfrost.io, a `project_id` token is automatically generated for each project. HTTP header of your request MUST include this `project_id` in order to authenticate against Blockfrost servers.  ## Available networks  At the moment, you can use the following networks. Please, note that each network has its own `project_id`.  <table>   <tr><td><b>Network</b></td><td><b>Endpoint</b></td></tr>   <tr><td>Cardano mainnet</td><td><tt>https://cardano-mainnet.blockfrost.io/api/v0</td></tt></tr>   <tr><td>Cardano testnet</td><td><tt>https://cardano-testnet.blockfrost.io/api/v0</tt></td></tr>   <tr><td>InterPlanetary File System</td><td><tt>https://ipfs.blockfrost.io/api/v0</tt></td></tr> </table>  ## Concepts  * All endpoints return either a JSON object or an array. * Data is returned in *ascending* (oldest first, newest last) order, if not stated otherwise.   * You might use the `?order=desc` query parameter to reverse this order. * By default, we return 100 results at a time. You have to use `?page=2` to list through the results. * All time and timestamp related fields (except `server_time`) are in seconds of UNIX time. * All amounts are returned in Lovelaces, where 1 ADA = 1 000 000 Lovelaces. * Addresses, accounts and pool IDs are in Bech32 format. * All values are case sensitive. * All hex encoded values are lower case. * Examples are not based on real data. Any resemblance to actual events is purely coincidental. * We allow to upload files up to 100MB of size to IPFS. This might increase in the future.  ## Errors  ### HTTP Status codes  The following are HTTP status code your application might receive when reaching Blockfrost endpoints and it should handle all of these cases.  * HTTP `400` return code is used when the request is not valid. * HTTP `402` return code is used when the projects exceed their daily request limit. * HTTP `403` return code is used when the request is not authenticated. * HTTP `404` return code is used when the resource doesn't exist. * HTTP `418` return code is used when the user has been auto-banned for flooding too much after previously receiving error code `402` or `429`. * HTTP `425` return code is used when the user has submitted a transaction when the mempool is already full, not accepting new txs straight away. * HTTP `429` return code is used when the user has sent too many requests in a given amount of time and therefore has been rate-limited. * HTTP `500` return code is used when our endpoints are having a problem.  ### Error codes  An internal error code number is used for better indication of the error in question. It is passed using the following payload.  ```json {   \"status_code\": 403,   \"error\": \"Forbidden\",   \"message\": \"Invalid project token.\" } ``` ## Limits  There are two types of limits we are enforcing:  The first depends on your plan and is the number of request we allow per day. We defined the day from midnight to midnight of UTC time.  The second is rate limiting. We limit an end user, distinguished by IP address, to 10 requests per second. On top of that, we allow each user to send burst of 500 requests, which cools off at rate of 10 requests per second. In essence, a user is allowed to make another whole burst after (currently) 500/10 = 50 seconds. E.g. if a user attemtps to make a call 3 seconds after whole burst, 30 requests will be processed. We believe this should be sufficient for most of the use cases. If it is not and you have a specific use case, please get in touch with us, and we will make sure to take it into account as much as we can.  ## SDKs  We support a number of SDKs that will help you in developing your application on top of Blockfrost.  <table>   <tr><td><b>Programming language</b></td><td><b>SDK</b></td></tr>   <tr><td>JavaScript</td><td><a href=\"https://github.com/blockfrost/blockfrost-js\">blockfrost-js</a></tr>   <tr><td>Haskell</td><td><a href=\"https://github.com/blockfrost/blockfrost-haskell\">blockfrost-haskell</a></tr>   <tr><td>Python</td><td><a href=\"https://github.com/blockfrost/blockfrost-python\">blockfrost-python</a></tr>   <tr><td>Rust</td><td><a href=\"https://github.com/blockfrost/blockfrost-rust\">blockfrost-rust</a></tr>   <tr><td>Golang</td><td><a href=\"https://github.com/blockfrost/blockfrost-go\">blockfrost-go</a></tr>   <tr><td>Ruby</td><td><a href=\"https://github.com/blockfrost/blockfrost-ruby\">blockfrost-ruby</a></tr>   <tr><td>Java</td><td><a href=\"https://github.com/blockfrost/blockfrost-java\">blockfrost-java</a></tr>   <tr><td>Scala</td><td><a href=\"https://github.com/blockfrost/blockfrost-scala\">blockfrost-scala</a></tr>   <tr><td>Swift</td><td><a href=\"https://github.com/blockfrost/blockfrost-swift\">blockfrost-swift</a></tr>   <tr><td>Kotlin</td><td><a href=\"https://github.com/blockfrost/blockfrost-kotlin\">blockfrost-kotlin</a></tr>   <tr><td>Elixir</td><td><a href=\"https://github.com/blockfrost/blockfrost-elixir\">blockfrost-elixir</a></tr>   <tr><td>.NET</td><td><a href=\"https://github.com/blockfrost/blockfrost-dotnet\">blockfrost-dotnet</a></tr>   <tr><td>Arduino</td><td><a href=\"https://github.com/blockfrost/blockfrost-arduino\">blockfrost-arduino</a></tr> </table> 
 *
 * The version of the OpenAPI document: 0.1.36
 * Contact: contact@blockfrost.io
 * Generated by: https://github.com/openapitools/openapi-generator.git
 */


using Xunit;

using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Model;
using Org.OpenAPITools.Client;
using System.Reflection;
using Newtonsoft.Json;

namespace Org.OpenAPITools.Test.Model
{
    /// <summary>
    ///  Class for testing EpochParamContent
    /// </summary>
    /// <remarks>
    /// This file is automatically generated by OpenAPI Generator (https://openapi-generator.tech).
    /// Please update the test case below to test the model.
    /// </remarks>
    public class EpochParamContentTests : IDisposable
    {
        // TODO uncomment below to declare an instance variable for EpochParamContent
        //private EpochParamContent instance;

        public EpochParamContentTests()
        {
            // TODO uncomment below to create an instance of EpochParamContent
            //instance = new EpochParamContent();
        }

        public void Dispose()
        {
            // Cleanup when everything is done.
        }

        /// <summary>
        /// Test an instance of EpochParamContent
        /// </summary>
        [Fact]
        public void EpochParamContentInstanceTest()
        {
            // TODO uncomment below to test "IsType" EpochParamContent
            //Assert.IsType<EpochParamContent>(instance);
        }


        /// <summary>
        /// Test the property 'Epoch'
        /// </summary>
        [Fact]
        public void EpochTest()
        {
            // TODO unit test for the property 'Epoch'
        }
        /// <summary>
        /// Test the property 'MinFeeA'
        /// </summary>
        [Fact]
        public void MinFeeATest()
        {
            // TODO unit test for the property 'MinFeeA'
        }
        /// <summary>
        /// Test the property 'MinFeeB'
        /// </summary>
        [Fact]
        public void MinFeeBTest()
        {
            // TODO unit test for the property 'MinFeeB'
        }
        /// <summary>
        /// Test the property 'MaxBlockSize'
        /// </summary>
        [Fact]
        public void MaxBlockSizeTest()
        {
            // TODO unit test for the property 'MaxBlockSize'
        }
        /// <summary>
        /// Test the property 'MaxTxSize'
        /// </summary>
        [Fact]
        public void MaxTxSizeTest()
        {
            // TODO unit test for the property 'MaxTxSize'
        }
        /// <summary>
        /// Test the property 'MaxBlockHeaderSize'
        /// </summary>
        [Fact]
        public void MaxBlockHeaderSizeTest()
        {
            // TODO unit test for the property 'MaxBlockHeaderSize'
        }
        /// <summary>
        /// Test the property 'KeyDeposit'
        /// </summary>
        [Fact]
        public void KeyDepositTest()
        {
            // TODO unit test for the property 'KeyDeposit'
        }
        /// <summary>
        /// Test the property 'PoolDeposit'
        /// </summary>
        [Fact]
        public void PoolDepositTest()
        {
            // TODO unit test for the property 'PoolDeposit'
        }
        /// <summary>
        /// Test the property 'EMax'
        /// </summary>
        [Fact]
        public void EMaxTest()
        {
            // TODO unit test for the property 'EMax'
        }
        /// <summary>
        /// Test the property 'NOpt'
        /// </summary>
        [Fact]
        public void NOptTest()
        {
            // TODO unit test for the property 'NOpt'
        }
        /// <summary>
        /// Test the property 'A0'
        /// </summary>
        [Fact]
        public void A0Test()
        {
            // TODO unit test for the property 'A0'
        }
        /// <summary>
        /// Test the property 'Rho'
        /// </summary>
        [Fact]
        public void RhoTest()
        {
            // TODO unit test for the property 'Rho'
        }
        /// <summary>
        /// Test the property 'Tau'
        /// </summary>
        [Fact]
        public void TauTest()
        {
            // TODO unit test for the property 'Tau'
        }
        /// <summary>
        /// Test the property 'DecentralisationParam'
        /// </summary>
        [Fact]
        public void DecentralisationParamTest()
        {
            // TODO unit test for the property 'DecentralisationParam'
        }
        /// <summary>
        /// Test the property 'ExtraEntropy'
        /// </summary>
        [Fact]
        public void ExtraEntropyTest()
        {
            // TODO unit test for the property 'ExtraEntropy'
        }
        /// <summary>
        /// Test the property 'ProtocolMajorVer'
        /// </summary>
        [Fact]
        public void ProtocolMajorVerTest()
        {
            // TODO unit test for the property 'ProtocolMajorVer'
        }
        /// <summary>
        /// Test the property 'ProtocolMinorVer'
        /// </summary>
        [Fact]
        public void ProtocolMinorVerTest()
        {
            // TODO unit test for the property 'ProtocolMinorVer'
        }
        /// <summary>
        /// Test the property 'MinUtxo'
        /// </summary>
        [Fact]
        public void MinUtxoTest()
        {
            // TODO unit test for the property 'MinUtxo'
        }
        /// <summary>
        /// Test the property 'MinPoolCost'
        /// </summary>
        [Fact]
        public void MinPoolCostTest()
        {
            // TODO unit test for the property 'MinPoolCost'
        }
        /// <summary>
        /// Test the property 'Nonce'
        /// </summary>
        [Fact]
        public void NonceTest()
        {
            // TODO unit test for the property 'Nonce'
        }
        /// <summary>
        /// Test the property 'PriceMem'
        /// </summary>
        [Fact]
        public void PriceMemTest()
        {
            // TODO unit test for the property 'PriceMem'
        }
        /// <summary>
        /// Test the property 'PriceStep'
        /// </summary>
        [Fact]
        public void PriceStepTest()
        {
            // TODO unit test for the property 'PriceStep'
        }
        /// <summary>
        /// Test the property 'MaxTxExMem'
        /// </summary>
        [Fact]
        public void MaxTxExMemTest()
        {
            // TODO unit test for the property 'MaxTxExMem'
        }
        /// <summary>
        /// Test the property 'MaxTxExSteps'
        /// </summary>
        [Fact]
        public void MaxTxExStepsTest()
        {
            // TODO unit test for the property 'MaxTxExSteps'
        }
        /// <summary>
        /// Test the property 'MaxBlockExMem'
        /// </summary>
        [Fact]
        public void MaxBlockExMemTest()
        {
            // TODO unit test for the property 'MaxBlockExMem'
        }
        /// <summary>
        /// Test the property 'MaxBlockExSteps'
        /// </summary>
        [Fact]
        public void MaxBlockExStepsTest()
        {
            // TODO unit test for the property 'MaxBlockExSteps'
        }
        /// <summary>
        /// Test the property 'MaxValSize'
        /// </summary>
        [Fact]
        public void MaxValSizeTest()
        {
            // TODO unit test for the property 'MaxValSize'
        }
        /// <summary>
        /// Test the property 'CollateralPercent'
        /// </summary>
        [Fact]
        public void CollateralPercentTest()
        {
            // TODO unit test for the property 'CollateralPercent'
        }
        /// <summary>
        /// Test the property 'MaxCollateralInputs'
        /// </summary>
        [Fact]
        public void MaxCollateralInputsTest()
        {
            // TODO unit test for the property 'MaxCollateralInputs'
        }
        /// <summary>
        /// Test the property 'CoinsPerUtxoWord'
        /// </summary>
        [Fact]
        public void CoinsPerUtxoWordTest()
        {
            // TODO unit test for the property 'CoinsPerUtxoWord'
        }

    }

}
