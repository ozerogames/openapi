/*
 * Blockfrost.io ~ API Documentation
 *
 * Blockfrost is an API as a service that allows users to interact with the Cardano blockchain and parts of its ecosystem.  ## Tokens  After signing up on https://blockfrost.io, a `project_id` token is automatically generated for each project. HTTP header of your request MUST include this `project_id` in order to authenticate against Blockfrost servers.  ## Available networks  At the moment, you can use the following networks. Please, note that each network has its own `project_id`.  <table>   <tr><td><b>Network</b></td><td><b>Endpoint</b></td></tr>   <tr><td>Cardano mainnet</td><td><tt>https://cardano-mainnet.blockfrost.io/api/v0</td></tt></tr>   <tr><td>Cardano testnet</td><td><tt>https://cardano-testnet.blockfrost.io/api/v0</tt></td></tr>   <tr><td>InterPlanetary File System</td><td><tt>https://ipfs.blockfrost.io/api/v0</tt></td></tr> </table>  ## Concepts  * All endpoints return either a JSON object or an array. * Data is returned in *ascending* (oldest first, newest last) order, if not stated otherwise.   * You might use the `?order=desc` query parameter to reverse this order. * By default, we return 100 results at a time. You have to use `?page=2` to list through the results. * All time and timestamp related fields (except `server_time`) are in seconds of UNIX time. * All amounts are returned in Lovelaces, where 1 ADA = 1 000 000 Lovelaces. * Addresses, accounts and pool IDs are in Bech32 format. * All values are case sensitive. * All hex encoded values are lower case. * Examples are not based on real data. Any resemblance to actual events is purely coincidental. * We allow to upload files up to 100MB of size to IPFS. This might increase in the future.  ## Errors  ### HTTP Status codes  The following are HTTP status code your application might receive when reaching Blockfrost endpoints and it should handle all of these cases.  * HTTP `400` return code is used when the request is not valid. * HTTP `402` return code is used when the projects exceed their daily request limit. * HTTP `403` return code is used when the request is not authenticated. * HTTP `404` return code is used when the resource doesn't exist. * HTTP `418` return code is used when the user has been auto-banned for flooding too much after previously receiving error code `402` or `429`. * HTTP `425` return code is used when the user has submitted a transaction when the mempool is already full, not accepting new txs straight away. * HTTP `429` return code is used when the user has sent too many requests in a given amount of time and therefore has been rate-limited. * HTTP `500` return code is used when our endpoints are having a problem.  ### Error codes  An internal error code number is used for better indication of the error in question. It is passed using the following payload.  ```json {   \"status_code\": 403,   \"error\": \"Forbidden\",   \"message\": \"Invalid project token.\" } ``` ## Limits  There are two types of limits we are enforcing:  The first depends on your plan and is the number of request we allow per day. We defined the day from midnight to midnight of UTC time.  The second is rate limiting. We limit an end user, distinguished by IP address, to 10 requests per second. On top of that, we allow each user to send burst of 500 requests, which cools off at rate of 10 requests per second. In essence, a user is allowed to make another whole burst after (currently) 500/10 = 50 seconds. E.g. if a user attemtps to make a call 3 seconds after whole burst, 30 requests will be processed. We believe this should be sufficient for most of the use cases. If it is not and you have a specific use case, please get in touch with us, and we will make sure to take it into account as much as we can.  ## SDKs  We support a number of SDKs that will help you in developing your application on top of Blockfrost.  <table>   <tr><td><b>Programming language</b></td><td><b>SDK</b></td></tr>   <tr><td>JavaScript</td><td><a href=\"https://github.com/blockfrost/blockfrost-js\">blockfrost-js</a></tr>   <tr><td>Haskell</td><td><a href=\"https://github.com/blockfrost/blockfrost-haskell\">blockfrost-haskell</a></tr>   <tr><td>Python</td><td><a href=\"https://github.com/blockfrost/blockfrost-python\">blockfrost-python</a></tr>   <tr><td>Rust</td><td><a href=\"https://github.com/blockfrost/blockfrost-rust\">blockfrost-rust</a></tr>   <tr><td>Golang</td><td><a href=\"https://github.com/blockfrost/blockfrost-go\">blockfrost-go</a></tr>   <tr><td>Ruby</td><td><a href=\"https://github.com/blockfrost/blockfrost-ruby\">blockfrost-ruby</a></tr>   <tr><td>Java</td><td><a href=\"https://github.com/blockfrost/blockfrost-java\">blockfrost-java</a></tr>   <tr><td>Scala</td><td><a href=\"https://github.com/blockfrost/blockfrost-scala\">blockfrost-scala</a></tr>   <tr><td>Swift</td><td><a href=\"https://github.com/blockfrost/blockfrost-swift\">blockfrost-swift</a></tr>   <tr><td>Kotlin</td><td><a href=\"https://github.com/blockfrost/blockfrost-kotlin\">blockfrost-kotlin</a></tr>   <tr><td>Elixir</td><td><a href=\"https://github.com/blockfrost/blockfrost-elixir\">blockfrost-elixir</a></tr>   <tr><td>.NET</td><td><a href=\"https://github.com/blockfrost/blockfrost-dotnet\">blockfrost-dotnet</a></tr>   <tr><td>Arduino</td><td><a href=\"https://github.com/blockfrost/blockfrost-arduino\">blockfrost-arduino</a></tr> </table> 
 *
 * The version of the OpenAPI document: 0.1.36
 * Contact: contact@blockfrost.io
 * Generated by: https://github.com/openapitools/openapi-generator.git
 */

using System;
using System.IO;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using Xunit;

using Org.OpenAPITools.Client;
using Org.OpenAPITools.Api;
// uncomment below to import models
//using Org.OpenAPITools.Model;

namespace Org.OpenAPITools.Test.Api
{
    /// <summary>
    ///  Class for testing CardanoPoolsApi
    /// </summary>
    /// <remarks>
    /// This file is automatically generated by OpenAPI Generator (https://openapi-generator.tech).
    /// Please update the test case below to test the API endpoint.
    /// </remarks>
    public class CardanoPoolsApiTests : IDisposable
    {
        private CardanoPoolsApi instance;

        public CardanoPoolsApiTests()
        {
            instance = new CardanoPoolsApi();
        }

        public void Dispose()
        {
            // Cleanup when everything is done.
        }

        /// <summary>
        /// Test an instance of CardanoPoolsApi
        /// </summary>
        [Fact]
        public void InstanceTest()
        {
            // TODO uncomment below to test 'IsType' CardanoPoolsApi
            //Assert.IsType<CardanoPoolsApi>(instance);
        }

        /// <summary>
        /// Test PoolsExtendedGet
        /// </summary>
        [Fact]
        public void PoolsExtendedGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsExtendedGet(count, page, order);
            //Assert.IsType<List<Object>>(response);
        }

        /// <summary>
        /// Test PoolsGet
        /// </summary>
        [Fact]
        public void PoolsGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsGet(count, page, order);
            //Assert.IsType<List<string>>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdBlocksGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdBlocksGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsPoolIdBlocksGet(poolId, count, page, order);
            //Assert.IsType<List<string>>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdDelegatorsGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdDelegatorsGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsPoolIdDelegatorsGet(poolId, count, page, order);
            //Assert.IsType<List<Object>>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //var response = instance.PoolsPoolIdGet(poolId);
            //Assert.IsType<Pool>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdHistoryGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdHistoryGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsPoolIdHistoryGet(poolId, count, page, order);
            //Assert.IsType<List<Object>>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdMetadataGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdMetadataGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //var response = instance.PoolsPoolIdMetadataGet(poolId);
            //Assert.IsType<AnyOfpoolMetadataobject>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdRelaysGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdRelaysGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //var response = instance.PoolsPoolIdRelaysGet(poolId);
            //Assert.IsType<List<Object>>(response);
        }

        /// <summary>
        /// Test PoolsPoolIdUpdatesGet
        /// </summary>
        [Fact]
        public void PoolsPoolIdUpdatesGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //string poolId = null;
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsPoolIdUpdatesGet(poolId, count, page, order);
            //Assert.IsType<List<Object>>(response);
        }

        /// <summary>
        /// Test PoolsRetiredGet
        /// </summary>
        [Fact]
        public void PoolsRetiredGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsRetiredGet(count, page, order);
            //Assert.IsType<List<Object>>(response);
        }

        /// <summary>
        /// Test PoolsRetiringGet
        /// </summary>
        [Fact]
        public void PoolsRetiringGetTest()
        {
            // TODO uncomment below to test the method and replace null with proper value
            //int? count = null;
            //int? page = null;
            //string order = null;
            //var response = instance.PoolsRetiringGet(count, page, order);
            //Assert.IsType<List<Object>>(response);
        }
    }
}
