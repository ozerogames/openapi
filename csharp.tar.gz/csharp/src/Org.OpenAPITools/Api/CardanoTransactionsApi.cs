/*
 * Blockfrost.io ~ API Documentation
 *
 * Blockfrost is an API as a service that allows users to interact with the Cardano blockchain and parts of its ecosystem.  ## Tokens  After signing up on https://blockfrost.io, a `project_id` token is automatically generated for each project. HTTP header of your request MUST include this `project_id` in order to authenticate against Blockfrost servers.  ## Available networks  At the moment, you can use the following networks. Please, note that each network has its own `project_id`.  <table>   <tr><td><b>Network</b></td><td><b>Endpoint</b></td></tr>   <tr><td>Cardano mainnet</td><td><tt>https://cardano-mainnet.blockfrost.io/api/v0</td></tt></tr>   <tr><td>Cardano testnet</td><td><tt>https://cardano-testnet.blockfrost.io/api/v0</tt></td></tr>   <tr><td>InterPlanetary File System</td><td><tt>https://ipfs.blockfrost.io/api/v0</tt></td></tr> </table>  ## Concepts  * All endpoints return either a JSON object or an array. * Data is returned in *ascending* (oldest first, newest last) order, if not stated otherwise.   * You might use the `?order=desc` query parameter to reverse this order. * By default, we return 100 results at a time. You have to use `?page=2` to list through the results. * All time and timestamp related fields (except `server_time`) are in seconds of UNIX time. * All amounts are returned in Lovelaces, where 1 ADA = 1 000 000 Lovelaces. * Addresses, accounts and pool IDs are in Bech32 format. * All values are case sensitive. * All hex encoded values are lower case. * Examples are not based on real data. Any resemblance to actual events is purely coincidental. * We allow to upload files up to 100MB of size to IPFS. This might increase in the future.  ## Errors  ### HTTP Status codes  The following are HTTP status code your application might receive when reaching Blockfrost endpoints and it should handle all of these cases.  * HTTP `400` return code is used when the request is not valid. * HTTP `402` return code is used when the projects exceed their daily request limit. * HTTP `403` return code is used when the request is not authenticated. * HTTP `404` return code is used when the resource doesn't exist. * HTTP `418` return code is used when the user has been auto-banned for flooding too much after previously receiving error code `402` or `429`. * HTTP `425` return code is used when the user has submitted a transaction when the mempool is already full, not accepting new txs straight away. * HTTP `429` return code is used when the user has sent too many requests in a given amount of time and therefore has been rate-limited. * HTTP `500` return code is used when our endpoints are having a problem.  ### Error codes  An internal error code number is used for better indication of the error in question. It is passed using the following payload.  ```json {   \"status_code\": 403,   \"error\": \"Forbidden\",   \"message\": \"Invalid project token.\" } ``` ## Limits  There are two types of limits we are enforcing:  The first depends on your plan and is the number of request we allow per day. We defined the day from midnight to midnight of UTC time.  The second is rate limiting. We limit an end user, distinguished by IP address, to 10 requests per second. On top of that, we allow each user to send burst of 500 requests, which cools off at rate of 10 requests per second. In essence, a user is allowed to make another whole burst after (currently) 500/10 = 50 seconds. E.g. if a user attemtps to make a call 3 seconds after whole burst, 30 requests will be processed. We believe this should be sufficient for most of the use cases. If it is not and you have a specific use case, please get in touch with us, and we will make sure to take it into account as much as we can.  ## SDKs  We support a number of SDKs that will help you in developing your application on top of Blockfrost.  <table>   <tr><td><b>Programming language</b></td><td><b>SDK</b></td></tr>   <tr><td>JavaScript</td><td><a href=\"https://github.com/blockfrost/blockfrost-js\">blockfrost-js</a></tr>   <tr><td>Haskell</td><td><a href=\"https://github.com/blockfrost/blockfrost-haskell\">blockfrost-haskell</a></tr>   <tr><td>Python</td><td><a href=\"https://github.com/blockfrost/blockfrost-python\">blockfrost-python</a></tr>   <tr><td>Rust</td><td><a href=\"https://github.com/blockfrost/blockfrost-rust\">blockfrost-rust</a></tr>   <tr><td>Golang</td><td><a href=\"https://github.com/blockfrost/blockfrost-go\">blockfrost-go</a></tr>   <tr><td>Ruby</td><td><a href=\"https://github.com/blockfrost/blockfrost-ruby\">blockfrost-ruby</a></tr>   <tr><td>Java</td><td><a href=\"https://github.com/blockfrost/blockfrost-java\">blockfrost-java</a></tr>   <tr><td>Scala</td><td><a href=\"https://github.com/blockfrost/blockfrost-scala\">blockfrost-scala</a></tr>   <tr><td>Swift</td><td><a href=\"https://github.com/blockfrost/blockfrost-swift\">blockfrost-swift</a></tr>   <tr><td>Kotlin</td><td><a href=\"https://github.com/blockfrost/blockfrost-kotlin\">blockfrost-kotlin</a></tr>   <tr><td>Elixir</td><td><a href=\"https://github.com/blockfrost/blockfrost-elixir\">blockfrost-elixir</a></tr>   <tr><td>.NET</td><td><a href=\"https://github.com/blockfrost/blockfrost-dotnet\">blockfrost-dotnet</a></tr>   <tr><td>Arduino</td><td><a href=\"https://github.com/blockfrost/blockfrost-arduino\">blockfrost-arduino</a></tr> </table> 
 *
 * The version of the OpenAPI document: 0.1.36
 * Contact: contact@blockfrost.io
 * Generated by: https://github.com/openapitools/openapi-generator.git
 */


using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mime;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Org.OpenAPITools.Api
{

    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICardanoTransactionsApiSync : IApiAccessor
    {
        #region Synchronous Operations
        /// <summary>
        /// Submit a transaction
        /// </summary>
        /// <remarks>
        /// Submit an already serialized transaction to the network.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <returns>string</returns>
        string TxSubmitPost(string contentType);

        /// <summary>
        /// Submit a transaction
        /// </summary>
        /// <remarks>
        /// Submit an already serialized transaction to the network.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <returns>ApiResponse of string</returns>
        ApiResponse<string> TxSubmitPostWithHttpInfo(string contentType);
        /// <summary>
        /// Transaction delegation certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about delegation certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashDelegationsGet(string hash);

        /// <summary>
        /// Transaction delegation certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about delegation certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashDelegationsGetWithHttpInfo(string hash);
        /// <summary>
        /// Specific transaction
        /// </summary>
        /// <remarks>
        /// Return content of the requested transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>TxContent</returns>
        TxContent TxsHashGet(string hash);

        /// <summary>
        /// Specific transaction
        /// </summary>
        /// <remarks>
        /// Return content of the requested transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of TxContent</returns>
        ApiResponse<TxContent> TxsHashGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction metadata in CBOR
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata in CBOR.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashMetadataCborGet(string hash);

        /// <summary>
        /// Transaction metadata in CBOR
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata in CBOR.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashMetadataCborGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction metadata
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashMetadataGet(string hash);

        /// <summary>
        /// Transaction metadata
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashMetadataGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction MIRs
        /// </summary>
        /// <remarks>
        /// Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashMirsGet(string hash);

        /// <summary>
        /// Transaction MIRs
        /// </summary>
        /// <remarks>
        /// Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashMirsGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction stake pool retirement certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool retirements within a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashPoolRetiresGet(string hash);

        /// <summary>
        /// Transaction stake pool retirement certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool retirements within a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashPoolRetiresGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction stake pool registration and update certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashPoolUpdatesGet(string hash);

        /// <summary>
        /// Transaction stake pool registration and update certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashPoolUpdatesGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction redeemers
        /// </summary>
        /// <remarks>
        /// Obtain the transaction redeemers.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashRedeemersGet(string hash);

        /// <summary>
        /// Transaction redeemers
        /// </summary>
        /// <remarks>
        /// Obtain the transaction redeemers.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashRedeemersGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction stake addresses certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about (de)registration of stake addresses within a transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashStakesGet(string hash);

        /// <summary>
        /// Transaction stake addresses certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about (de)registration of stake addresses within a transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashStakesGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction UTXOs
        /// </summary>
        /// <remarks>
        /// Return the inputs and UTXOs of the specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>TxContentUtxo</returns>
        TxContentUtxo TxsHashUtxosGet(string hash);

        /// <summary>
        /// Transaction UTXOs
        /// </summary>
        /// <remarks>
        /// Return the inputs and UTXOs of the specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of TxContentUtxo</returns>
        ApiResponse<TxContentUtxo> TxsHashUtxosGetWithHttpInfo(string hash);
        /// <summary>
        /// Transaction withdrawal
        /// </summary>
        /// <remarks>
        /// Obtain information about withdrawals of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        List<Object> TxsHashWithdrawalsGet(string hash);

        /// <summary>
        /// Transaction withdrawal
        /// </summary>
        /// <remarks>
        /// Obtain information about withdrawals of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        ApiResponse<List<Object>> TxsHashWithdrawalsGetWithHttpInfo(string hash);
        #endregion Synchronous Operations
    }

    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICardanoTransactionsApiAsync : IApiAccessor
    {
        #region Asynchronous Operations
        /// <summary>
        /// Submit a transaction
        /// </summary>
        /// <remarks>
        /// Submit an already serialized transaction to the network.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of string</returns>
        System.Threading.Tasks.Task<string> TxSubmitPostAsync(string contentType, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Submit a transaction
        /// </summary>
        /// <remarks>
        /// Submit an already serialized transaction to the network.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (string)</returns>
        System.Threading.Tasks.Task<ApiResponse<string>> TxSubmitPostWithHttpInfoAsync(string contentType, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction delegation certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about delegation certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashDelegationsGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction delegation certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about delegation certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashDelegationsGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Specific transaction
        /// </summary>
        /// <remarks>
        /// Return content of the requested transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of TxContent</returns>
        System.Threading.Tasks.Task<TxContent> TxsHashGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Specific transaction
        /// </summary>
        /// <remarks>
        /// Return content of the requested transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (TxContent)</returns>
        System.Threading.Tasks.Task<ApiResponse<TxContent>> TxsHashGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction metadata in CBOR
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata in CBOR.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashMetadataCborGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction metadata in CBOR
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata in CBOR.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashMetadataCborGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction metadata
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashMetadataGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction metadata
        /// </summary>
        /// <remarks>
        /// Obtain the transaction metadata.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashMetadataGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction MIRs
        /// </summary>
        /// <remarks>
        /// Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashMirsGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction MIRs
        /// </summary>
        /// <remarks>
        /// Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashMirsGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction stake pool retirement certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool retirements within a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashPoolRetiresGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction stake pool retirement certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool retirements within a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashPoolRetiresGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction stake pool registration and update certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashPoolUpdatesGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction stake pool registration and update certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashPoolUpdatesGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction redeemers
        /// </summary>
        /// <remarks>
        /// Obtain the transaction redeemers.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashRedeemersGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction redeemers
        /// </summary>
        /// <remarks>
        /// Obtain the transaction redeemers.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashRedeemersGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction stake addresses certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about (de)registration of stake addresses within a transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashStakesGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction stake addresses certificates
        /// </summary>
        /// <remarks>
        /// Obtain information about (de)registration of stake addresses within a transaction. 
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashStakesGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction UTXOs
        /// </summary>
        /// <remarks>
        /// Return the inputs and UTXOs of the specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of TxContentUtxo</returns>
        System.Threading.Tasks.Task<TxContentUtxo> TxsHashUtxosGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction UTXOs
        /// </summary>
        /// <remarks>
        /// Return the inputs and UTXOs of the specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (TxContentUtxo)</returns>
        System.Threading.Tasks.Task<ApiResponse<TxContentUtxo>> TxsHashUtxosGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        /// <summary>
        /// Transaction withdrawal
        /// </summary>
        /// <remarks>
        /// Obtain information about withdrawals of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        System.Threading.Tasks.Task<List<Object>> TxsHashWithdrawalsGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));

        /// <summary>
        /// Transaction withdrawal
        /// </summary>
        /// <remarks>
        /// Obtain information about withdrawals of a specific transaction.
        /// </remarks>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        System.Threading.Tasks.Task<ApiResponse<List<Object>>> TxsHashWithdrawalsGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken));
        #endregion Asynchronous Operations
    }

    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICardanoTransactionsApi : ICardanoTransactionsApiSync, ICardanoTransactionsApiAsync
    {

    }

    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public partial class CardanoTransactionsApi : IDisposable, ICardanoTransactionsApi
    {
        private Org.OpenAPITools.Client.ExceptionFactory _exceptionFactory = (name, response) => null;

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class.
        /// **IMPORTANT** This will also create an instance of HttpClient, which is less than ideal.
        /// It's better to reuse the <see href="https://docs.microsoft.com/en-us/dotnet/architecture/microservices/implement-resilient-applications/use-httpclientfactory-to-implement-resilient-http-requests#issues-with-the-original-httpclient-class-available-in-net">HttpClient and HttpClientHandler</see>.
        /// </summary>
        /// <returns></returns>
        public CardanoTransactionsApi() : this((string)null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class.
        /// **IMPORTANT** This will also create an instance of HttpClient, which is less than ideal.
        /// It's better to reuse the <see href="https://docs.microsoft.com/en-us/dotnet/architecture/microservices/implement-resilient-applications/use-httpclientfactory-to-implement-resilient-http-requests#issues-with-the-original-httpclient-class-available-in-net">HttpClient and HttpClientHandler</see>.
        /// </summary>
        /// <param name="basePath">The target service's base path in URL format.</param>
        /// <exception cref="ArgumentException"></exception>
        /// <returns></returns>
        public CardanoTransactionsApi(string basePath)
        {
            this.Configuration = Org.OpenAPITools.Client.Configuration.MergeConfigurations(
                Org.OpenAPITools.Client.GlobalConfiguration.Instance,
                new Org.OpenAPITools.Client.Configuration { BasePath = basePath }
            );
            this.ApiClient = new Org.OpenAPITools.Client.ApiClient(this.Configuration.BasePath);
            this.Client =  this.ApiClient;
            this.AsynchronousClient = this.ApiClient;
            this.ExceptionFactory = Org.OpenAPITools.Client.Configuration.DefaultExceptionFactory;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class using Configuration object.
        /// **IMPORTANT** This will also create an instance of HttpClient, which is less than ideal.
        /// It's better to reuse the <see href="https://docs.microsoft.com/en-us/dotnet/architecture/microservices/implement-resilient-applications/use-httpclientfactory-to-implement-resilient-http-requests#issues-with-the-original-httpclient-class-available-in-net">HttpClient and HttpClientHandler</see>.
        /// </summary>
        /// <param name="configuration">An instance of Configuration.</param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <returns></returns>
        public CardanoTransactionsApi(Org.OpenAPITools.Client.Configuration configuration)
        {
            if (configuration == null) throw new ArgumentNullException("configuration");

            this.Configuration = Org.OpenAPITools.Client.Configuration.MergeConfigurations(
                Org.OpenAPITools.Client.GlobalConfiguration.Instance,
                configuration
            );
            this.ApiClient = new Org.OpenAPITools.Client.ApiClient(this.Configuration.BasePath);
            this.Client = this.ApiClient;
            this.AsynchronousClient = this.ApiClient;
            ExceptionFactory = Org.OpenAPITools.Client.Configuration.DefaultExceptionFactory;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class.
        /// </summary>
        /// <param name="client">An instance of HttpClient.</param>
        /// <param name="handler">An optional instance of HttpClientHandler that is used by HttpClient.</param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <returns></returns>
        /// <remarks>
        /// Some configuration settings will not be applied without passing an HttpClientHandler.
        /// The features affected are: Setting and Retrieving Cookies, Client Certificates, Proxy settings.
        /// </remarks>
        public CardanoTransactionsApi(HttpClient client, HttpClientHandler handler = null) : this(client, (string)null, handler)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class.
        /// </summary>
        /// <param name="client">An instance of HttpClient.</param>
        /// <param name="basePath">The target service's base path in URL format.</param>
        /// <param name="handler">An optional instance of HttpClientHandler that is used by HttpClient.</param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <exception cref="ArgumentException"></exception>
        /// <returns></returns>
        /// <remarks>
        /// Some configuration settings will not be applied without passing an HttpClientHandler.
        /// The features affected are: Setting and Retrieving Cookies, Client Certificates, Proxy settings.
        /// </remarks>
        public CardanoTransactionsApi(HttpClient client, string basePath, HttpClientHandler handler = null)
        {
            if (client == null) throw new ArgumentNullException("client");

            this.Configuration = Org.OpenAPITools.Client.Configuration.MergeConfigurations(
                Org.OpenAPITools.Client.GlobalConfiguration.Instance,
                new Org.OpenAPITools.Client.Configuration { BasePath = basePath }
            );
            this.ApiClient = new Org.OpenAPITools.Client.ApiClient(client, this.Configuration.BasePath, handler);
            this.Client =  this.ApiClient;
            this.AsynchronousClient = this.ApiClient;
            this.ExceptionFactory = Org.OpenAPITools.Client.Configuration.DefaultExceptionFactory;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class using Configuration object.
        /// </summary>
        /// <param name="client">An instance of HttpClient.</param>
        /// <param name="configuration">An instance of Configuration.</param>
        /// <param name="handler">An optional instance of HttpClientHandler that is used by HttpClient.</param>
        /// <exception cref="ArgumentNullException"></exception>
        /// <returns></returns>
        /// <remarks>
        /// Some configuration settings will not be applied without passing an HttpClientHandler.
        /// The features affected are: Setting and Retrieving Cookies, Client Certificates, Proxy settings.
        /// </remarks>
        public CardanoTransactionsApi(HttpClient client, Org.OpenAPITools.Client.Configuration configuration, HttpClientHandler handler = null)
        {
            if (configuration == null) throw new ArgumentNullException("configuration");
            if (client == null) throw new ArgumentNullException("client");

            this.Configuration = Org.OpenAPITools.Client.Configuration.MergeConfigurations(
                Org.OpenAPITools.Client.GlobalConfiguration.Instance,
                configuration
            );
            this.ApiClient = new Org.OpenAPITools.Client.ApiClient(client, this.Configuration.BasePath, handler);
            this.Client = this.ApiClient;
            this.AsynchronousClient = this.ApiClient;
            ExceptionFactory = Org.OpenAPITools.Client.Configuration.DefaultExceptionFactory;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CardanoTransactionsApi"/> class
        /// using a Configuration object and client instance.
        /// </summary>
        /// <param name="client">The client interface for synchronous API access.</param>
        /// <param name="asyncClient">The client interface for asynchronous API access.</param>
        /// <param name="configuration">The configuration object.</param>
        /// <exception cref="ArgumentNullException"></exception>
        public CardanoTransactionsApi(Org.OpenAPITools.Client.ISynchronousClient client, Org.OpenAPITools.Client.IAsynchronousClient asyncClient, Org.OpenAPITools.Client.IReadableConfiguration configuration)
        {
            if (client == null) throw new ArgumentNullException("client");
            if (asyncClient == null) throw new ArgumentNullException("asyncClient");
            if (configuration == null) throw new ArgumentNullException("configuration");

            this.Client = client;
            this.AsynchronousClient = asyncClient;
            this.Configuration = configuration;
            this.ExceptionFactory = Org.OpenAPITools.Client.Configuration.DefaultExceptionFactory;
        }

        /// <summary>
        /// Disposes resources if they were created by us
        /// </summary>
        public void Dispose()
        {
            this.ApiClient?.Dispose();
        }

        /// <summary>
        /// Holds the ApiClient if created
        /// </summary>
        public Org.OpenAPITools.Client.ApiClient ApiClient { get; set; } = null;

        /// <summary>
        /// The client for accessing this underlying API asynchronously.
        /// </summary>
        public Org.OpenAPITools.Client.IAsynchronousClient AsynchronousClient { get; set; }

        /// <summary>
        /// The client for accessing this underlying API synchronously.
        /// </summary>
        public Org.OpenAPITools.Client.ISynchronousClient Client { get; set; }

        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <value>The base path</value>
        public string GetBasePath()
        {
            return this.Configuration.BasePath;
        }

        /// <summary>
        /// Gets or sets the configuration object
        /// </summary>
        /// <value>An instance of the Configuration</value>
        public Org.OpenAPITools.Client.IReadableConfiguration Configuration { get; set; }

        /// <summary>
        /// Provides a factory method hook for the creation of exceptions.
        /// </summary>
        public Org.OpenAPITools.Client.ExceptionFactory ExceptionFactory
        {
            get
            {
                if (_exceptionFactory != null && _exceptionFactory.GetInvocationList().Length > 1)
                {
                    throw new InvalidOperationException("Multicast delegate for ExceptionFactory is unsupported.");
                }
                return _exceptionFactory;
            }
            set { _exceptionFactory = value; }
        }

        /// <summary>
        /// Submit a transaction Submit an already serialized transaction to the network.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <returns>string</returns>
        public string TxSubmitPost(string contentType)
        {
            Org.OpenAPITools.Client.ApiResponse<string> localVarResponse = TxSubmitPostWithHttpInfo(contentType);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Submit a transaction Submit an already serialized transaction to the network.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <returns>ApiResponse of string</returns>
        public Org.OpenAPITools.Client.ApiResponse<string> TxSubmitPostWithHttpInfo(string contentType)
        {
            // verify the required parameter 'contentType' is set
            if (contentType == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'contentType' when calling CardanoTransactionsApi->TxSubmitPost");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.HeaderParameters.Add("Content-Type", Org.OpenAPITools.Client.ClientUtils.ParameterToString(contentType)); // header parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Post<string>("/tx/submit", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxSubmitPost", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Submit a transaction Submit an already serialized transaction to the network.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of string</returns>
        public async System.Threading.Tasks.Task<string> TxSubmitPostAsync(string contentType, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<string> localVarResponse = await TxSubmitPostWithHttpInfoAsync(contentType, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Submit a transaction Submit an already serialized transaction to the network.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="contentType"></param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (string)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<string>> TxSubmitPostWithHttpInfoAsync(string contentType, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'contentType' is set
            if (contentType == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'contentType' when calling CardanoTransactionsApi->TxSubmitPost");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.HeaderParameters.Add("Content-Type", Org.OpenAPITools.Client.ClientUtils.ParameterToString(contentType)); // header parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.PostAsync<string>("/tx/submit", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxSubmitPost", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction delegation certificates Obtain information about delegation certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashDelegationsGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashDelegationsGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction delegation certificates Obtain information about delegation certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashDelegationsGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashDelegationsGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/delegations", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashDelegationsGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction delegation certificates Obtain information about delegation certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashDelegationsGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashDelegationsGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction delegation certificates Obtain information about delegation certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashDelegationsGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashDelegationsGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/delegations", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashDelegationsGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Specific transaction Return content of the requested transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>TxContent</returns>
        public TxContent TxsHashGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<TxContent> localVarResponse = TxsHashGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Specific transaction Return content of the requested transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of TxContent</returns>
        public Org.OpenAPITools.Client.ApiResponse<TxContent> TxsHashGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<TxContent>("/txs/{hash}", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Specific transaction Return content of the requested transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of TxContent</returns>
        public async System.Threading.Tasks.Task<TxContent> TxsHashGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<TxContent> localVarResponse = await TxsHashGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Specific transaction Return content of the requested transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (TxContent)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<TxContent>> TxsHashGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<TxContent>("/txs/{hash}", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction metadata in CBOR Obtain the transaction metadata in CBOR.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashMetadataCborGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashMetadataCborGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction metadata in CBOR Obtain the transaction metadata in CBOR.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashMetadataCborGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashMetadataCborGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/metadata/cbor", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashMetadataCborGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction metadata in CBOR Obtain the transaction metadata in CBOR.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashMetadataCborGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashMetadataCborGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction metadata in CBOR Obtain the transaction metadata in CBOR.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashMetadataCborGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashMetadataCborGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/metadata/cbor", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashMetadataCborGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction metadata Obtain the transaction metadata.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashMetadataGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashMetadataGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction metadata Obtain the transaction metadata.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashMetadataGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashMetadataGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/metadata", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashMetadataGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction metadata Obtain the transaction metadata.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashMetadataGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashMetadataGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction metadata Obtain the transaction metadata.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashMetadataGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashMetadataGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/metadata", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashMetadataGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction MIRs Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashMirsGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashMirsGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction MIRs Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashMirsGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashMirsGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/mirs", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashMirsGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction MIRs Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashMirsGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashMirsGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction MIRs Obtain information about Move Instantaneous Rewards (MIRs) of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashMirsGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashMirsGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/mirs", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashMirsGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction stake pool retirement certificates Obtain information about stake pool retirements within a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashPoolRetiresGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashPoolRetiresGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction stake pool retirement certificates Obtain information about stake pool retirements within a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashPoolRetiresGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashPoolRetiresGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/pool_retires", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashPoolRetiresGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction stake pool retirement certificates Obtain information about stake pool retirements within a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashPoolRetiresGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashPoolRetiresGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction stake pool retirement certificates Obtain information about stake pool retirements within a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashPoolRetiresGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashPoolRetiresGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/pool_retires", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashPoolRetiresGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction stake pool registration and update certificates Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashPoolUpdatesGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashPoolUpdatesGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction stake pool registration and update certificates Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashPoolUpdatesGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashPoolUpdatesGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/pool_updates", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashPoolUpdatesGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction stake pool registration and update certificates Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashPoolUpdatesGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashPoolUpdatesGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction stake pool registration and update certificates Obtain information about stake pool registration and update certificates of a specific transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashPoolUpdatesGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashPoolUpdatesGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/pool_updates", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashPoolUpdatesGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction redeemers Obtain the transaction redeemers.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashRedeemersGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashRedeemersGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction redeemers Obtain the transaction redeemers.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashRedeemersGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashRedeemersGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/redeemers", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashRedeemersGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction redeemers Obtain the transaction redeemers.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashRedeemersGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashRedeemersGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction redeemers Obtain the transaction redeemers.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashRedeemersGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashRedeemersGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/redeemers", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashRedeemersGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction stake addresses certificates Obtain information about (de)registration of stake addresses within a transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashStakesGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashStakesGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction stake addresses certificates Obtain information about (de)registration of stake addresses within a transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashStakesGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashStakesGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/stakes", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashStakesGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction stake addresses certificates Obtain information about (de)registration of stake addresses within a transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashStakesGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashStakesGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction stake addresses certificates Obtain information about (de)registration of stake addresses within a transaction. 
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashStakesGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashStakesGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/stakes", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashStakesGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction UTXOs Return the inputs and UTXOs of the specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>TxContentUtxo</returns>
        public TxContentUtxo TxsHashUtxosGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<TxContentUtxo> localVarResponse = TxsHashUtxosGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction UTXOs Return the inputs and UTXOs of the specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <returns>ApiResponse of TxContentUtxo</returns>
        public Org.OpenAPITools.Client.ApiResponse<TxContentUtxo> TxsHashUtxosGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashUtxosGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<TxContentUtxo>("/txs/{hash}/utxos", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashUtxosGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction UTXOs Return the inputs and UTXOs of the specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of TxContentUtxo</returns>
        public async System.Threading.Tasks.Task<TxContentUtxo> TxsHashUtxosGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<TxContentUtxo> localVarResponse = await TxsHashUtxosGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction UTXOs Return the inputs and UTXOs of the specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (TxContentUtxo)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<TxContentUtxo>> TxsHashUtxosGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashUtxosGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<TxContentUtxo>("/txs/{hash}/utxos", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashUtxosGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction withdrawal Obtain information about withdrawals of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>List&lt;Object&gt;</returns>
        public List<Object> TxsHashWithdrawalsGet(string hash)
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = TxsHashWithdrawalsGetWithHttpInfo(hash);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction withdrawal Obtain information about withdrawals of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <returns>ApiResponse of List&lt;Object&gt;</returns>
        public Org.OpenAPITools.Client.ApiResponse<List<Object>> TxsHashWithdrawalsGetWithHttpInfo(string hash)
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashWithdrawalsGet");

            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };

            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request
            var localVarResponse = this.Client.Get<List<Object>>("/txs/{hash}/withdrawals", localVarRequestOptions, this.Configuration);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashWithdrawalsGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

        /// <summary>
        /// Transaction withdrawal Obtain information about withdrawals of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of List&lt;Object&gt;</returns>
        public async System.Threading.Tasks.Task<List<Object>> TxsHashWithdrawalsGetAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            Org.OpenAPITools.Client.ApiResponse<List<Object>> localVarResponse = await TxsHashWithdrawalsGetWithHttpInfoAsync(hash, cancellationToken).ConfigureAwait(false);
            return localVarResponse.Data;
        }

        /// <summary>
        /// Transaction withdrawal Obtain information about withdrawals of a specific transaction.
        /// </summary>
        /// <exception cref="Org.OpenAPITools.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="hash">Hash of the requested transaction.</param>
        /// <param name="cancellationToken">Cancellation Token to cancel the request.</param>
        /// <returns>Task of ApiResponse (List&lt;Object&gt;)</returns>
        public async System.Threading.Tasks.Task<Org.OpenAPITools.Client.ApiResponse<List<Object>>> TxsHashWithdrawalsGetWithHttpInfoAsync(string hash, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            // verify the required parameter 'hash' is set
            if (hash == null)
                throw new Org.OpenAPITools.Client.ApiException(400, "Missing required parameter 'hash' when calling CardanoTransactionsApi->TxsHashWithdrawalsGet");


            Org.OpenAPITools.Client.RequestOptions localVarRequestOptions = new Org.OpenAPITools.Client.RequestOptions();

            string[] _contentTypes = new string[] {
            };

            // to determine the Accept header
            string[] _accepts = new string[] {
                "application/json"
            };


            var localVarContentType = Org.OpenAPITools.Client.ClientUtils.SelectHeaderContentType(_contentTypes);
            if (localVarContentType != null) localVarRequestOptions.HeaderParameters.Add("Content-Type", localVarContentType);

            var localVarAccept = Org.OpenAPITools.Client.ClientUtils.SelectHeaderAccept(_accepts);
            if (localVarAccept != null) localVarRequestOptions.HeaderParameters.Add("Accept", localVarAccept);

            localVarRequestOptions.PathParameters.Add("hash", Org.OpenAPITools.Client.ClientUtils.ParameterToString(hash)); // path parameter

            // authentication (ApiKeyAuth) required
            if (!string.IsNullOrEmpty(this.Configuration.GetApiKeyWithPrefix("project_id")))
            {
                localVarRequestOptions.HeaderParameters.Add("project_id", this.Configuration.GetApiKeyWithPrefix("project_id"));
            }

            // make the HTTP request

            var localVarResponse = await this.AsynchronousClient.GetAsync<List<Object>>("/txs/{hash}/withdrawals", localVarRequestOptions, this.Configuration, cancellationToken).ConfigureAwait(false);

            if (this.ExceptionFactory != null)
            {
                Exception _exception = this.ExceptionFactory("TxsHashWithdrawalsGet", localVarResponse);
                if (_exception != null) throw _exception;
            }

            return localVarResponse;
        }

    }
}
