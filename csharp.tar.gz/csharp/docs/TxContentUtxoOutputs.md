# Org.OpenAPITools.Model.TxContentUtxoOutputs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** | Output address | 
**Amount** | [**List&lt;TxContentOutputAmount&gt;**](TxContentOutputAmount.md) |  | 
**OutputIndex** | **int** | UTXO index in the transaction | 
**DataHash** | **string** | The hash of the transaction output datum | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

