# Org.OpenAPITools.Model.EpochParamContent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Epoch** | **int** | Epoch number | 
**MinFeeA** | **int** | The linear factor for the minimum fee calculation for given epoch | 
**MinFeeB** | **int** | The constant factor for the minimum fee calculation | 
**MaxBlockSize** | **int** | Maximum block body size in Bytes | 
**MaxTxSize** | **int** | Maximum transaction size | 
**MaxBlockHeaderSize** | **int** | Maximum block header size | 
**KeyDeposit** | **string** | The amount of a key registration deposit in Lovelaces | 
**PoolDeposit** | **string** | The amount of a pool registration deposit in Lovelaces | 
**EMax** | **int** | Epoch bound on pool retirement | 
**NOpt** | **int** | Desired number of pools | 
**A0** | **decimal** | Pool pledge influence | 
**Rho** | **decimal** | Monetary expansion | 
**Tau** | **decimal** | Treasury expansion | 
**DecentralisationParam** | **decimal** | Percentage of blocks produced by federated nodes | 
**ExtraEntropy** | **Object** | Seed for extra entropy | 
**ProtocolMajorVer** | **int** | Accepted protocol major version | 
**ProtocolMinorVer** | **int** | Accepted protocol minor version | 
**MinUtxo** | **string** | Minimum UTXO value | 
**MinPoolCost** | **string** | Minimum stake cost forced on the pool | 
**Nonce** | **string** | Epoch number only used once | 
**PriceMem** | **decimal?** | The per word cost of script memory usage | 
**PriceStep** | **decimal?** | The cost of script execution step usage | 
**MaxTxExMem** | **string** | The maximum number of execution memory allowed to be used in a single transaction | 
**MaxTxExSteps** | **string** | The maximum number of execution steps allowed to be used in a single transaction | 
**MaxBlockExMem** | **string** | The maximum number of execution memory allowed to be used in a single block | 
**MaxBlockExSteps** | **string** | The maximum number of execution steps allowed to be used in a single block | 
**MaxValSize** | **string** | The maximum Val size | 
**CollateralPercent** | **int?** | The percentage of the transactions fee which must be provided as collateral when including non-native scripts | 
**MaxCollateralInputs** | **int?** | The maximum number of collateral inputs allowed in a transaction | 
**CoinsPerUtxoWord** | **string** | The cost per UTxO word | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

