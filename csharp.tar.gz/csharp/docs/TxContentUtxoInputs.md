# Org.OpenAPITools.Model.TxContentUtxoInputs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** | Input address | 
**Amount** | [**List&lt;TxContentOutputAmount&gt;**](TxContentOutputAmount.md) |  | 
**TxHash** | **string** | Hash of the UTXO transaction | 
**OutputIndex** | **int** | UTXO index in the transaction | 
**DataHash** | **string** | The hash of the transaction output datum | 
**Collateral** | **bool** | Whether the input is a collateral consumed on script validation failure | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

