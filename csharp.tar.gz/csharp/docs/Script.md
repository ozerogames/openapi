# Org.OpenAPITools.Model.Script

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ScriptHash** | **string** | Script hash | 
**Type** | **string** | Type of the script language | 
**SerialisedSize** | **int?** | The size of the CBOR serialised script, if a Plutus script | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

