# Org.OpenAPITools.Model.AccountAddressesTotal

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StakeAddress** | **string** | Bech32 encoded stake address | 
**ReceivedSum** | [**List&lt;AccountAddressesTotalReceivedSum&gt;**](AccountAddressesTotalReceivedSum.md) |  | 
**SentSum** | [**List&lt;AccountAddressesTotalReceivedSum&gt;**](AccountAddressesTotalReceivedSum.md) |  | 
**TxCount** | **int** | Count of all transactions for all addresses associated with the account | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

