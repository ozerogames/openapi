# Org.OpenAPITools.Model.AccountAddressesTotalReceivedSum
The sum of all the UTXO per asset for all addresses associated with the account

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Unit** | **string** | The unit of the value | 
**Quantity** | **string** | The quantity of the unit | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

