# Org.OpenAPITools.Api.CardanoAssetsApi

All URIs are relative to *https://cardano-mainnet.blockfrost.io/api/v0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AssetsAssetAddressesGet**](CardanoAssetsApi.md#assetsassetaddressesget) | **GET** /assets/{asset}/addresses | Asset addresses
[**AssetsAssetGet**](CardanoAssetsApi.md#assetsassetget) | **GET** /assets/{asset} | Specific asset
[**AssetsAssetHistoryGet**](CardanoAssetsApi.md#assetsassethistoryget) | **GET** /assets/{asset}/history | Asset history
[**AssetsAssetTransactionsGet**](CardanoAssetsApi.md#assetsassettransactionsget) | **GET** /assets/{asset}/transactions | Asset transactions
[**AssetsAssetTxsGet**](CardanoAssetsApi.md#assetsassettxsget) | **GET** /assets/{asset}/txs | Asset transactions
[**AssetsGet**](CardanoAssetsApi.md#assetsget) | **GET** /assets | Assets
[**AssetsPolicyPolicyIdGet**](CardanoAssetsApi.md#assetspolicypolicyidget) | **GET** /assets/policy/{policy_id} | Assets of a specific policy


<a name="assetsassetaddressesget"></a>
# **AssetsAssetAddressesGet**
> List&lt;Object&gt; AssetsAssetAddressesGet (string asset, int? count = null, int? page = null, string order = null)

Asset addresses

List of a addresses containing a specific asset

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsAssetAddressesGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var asset = b0d07d45fe9514f80213f4020e5a61241458be626841cde717cb38a76e7574636f696e;  // string | Concatenation of the policy_id and hex-encoded asset_name
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Asset addresses
                List<Object> result = apiInstance.AssetsAssetAddressesGet(asset, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsAssetAddressesGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asset** | **string**| Concatenation of the policy_id and hex-encoded asset_name | 
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about the history of a specific asset |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assetsassetget"></a>
# **AssetsAssetGet**
> Asset AssetsAssetGet (string asset)

Specific asset

Information about a specific asset

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsAssetGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var asset = b0d07d45fe9514f80213f4020e5a61241458be626841cde717cb38a76e7574636f696e;  // string | Concatenation of the policy_id and hex-encoded asset_name

            try
            {
                // Specific asset
                Asset result = apiInstance.AssetsAssetGet(asset);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsAssetGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asset** | **string**| Concatenation of the policy_id and hex-encoded asset_name | 

### Return type

[**Asset**](Asset.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about a specific asset |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assetsassethistoryget"></a>
# **AssetsAssetHistoryGet**
> List&lt;Object&gt; AssetsAssetHistoryGet (string asset, int? count = null, int? page = null, string order = null)

Asset history

History of a specific asset

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsAssetHistoryGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var asset = b0d07d45fe9514f80213f4020e5a61241458be626841cde717cb38a76e7574636f696e;  // string | Concatenation of the policy_id and hex-encoded asset_name
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Asset history
                List<Object> result = apiInstance.AssetsAssetHistoryGet(asset, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsAssetHistoryGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asset** | **string**| Concatenation of the policy_id and hex-encoded asset_name | 
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about the history of a specific asset |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assetsassettransactionsget"></a>
# **AssetsAssetTransactionsGet**
> List&lt;Object&gt; AssetsAssetTransactionsGet (string asset, int? count = null, int? page = null, string order = null)

Asset transactions

List of a specific asset transactions

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsAssetTransactionsGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var asset = b0d07d45fe9514f80213f4020e5a61241458be626841cde717cb38a76e7574636f696e;  // string | Concatenation of the policy_id and hex-encoded asset_name
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Asset transactions
                List<Object> result = apiInstance.AssetsAssetTransactionsGet(asset, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsAssetTransactionsGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asset** | **string**| Concatenation of the policy_id and hex-encoded asset_name | 
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about the history of a specific asset |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assetsassettxsget"></a>
# **AssetsAssetTxsGet**
> List&lt;string&gt; AssetsAssetTxsGet (string asset, int? count = null, int? page = null, string order = null)

Asset transactions

List of a specific asset transactions

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsAssetTxsGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var asset = b0d07d45fe9514f80213f4020e5a61241458be626841cde717cb38a76e7574636f696e;  // string | Concatenation of the policy_id and hex-encoded asset_name
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Asset transactions
                List<string> result = apiInstance.AssetsAssetTxsGet(asset, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsAssetTxsGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **asset** | **string**| Concatenation of the policy_id and hex-encoded asset_name | 
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<string>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about the history of a specific asset |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assetsget"></a>
# **AssetsGet**
> List&lt;Object&gt; AssetsGet (int? count = null, int? page = null, string order = null)

Assets

List of assets.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Assets
                List<Object> result = apiInstance.AssetsGet(count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return list of assets |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="assetspolicypolicyidget"></a>
# **AssetsPolicyPolicyIdGet**
> List&lt;Object&gt; AssetsPolicyPolicyIdGet (string policyId, int? count = null, int? page = null, string order = null)

Assets of a specific policy

List of asset minted under a specific policy

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class AssetsPolicyPolicyIdGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoAssetsApi(httpClient, config, httpClientHandler);
            var policyId = 476039a0949cf0b22f6a800f56780184c44533887ca6e821007840c3;  // string | Specific policy_id
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Assets of a specific policy
                List<Object> result = apiInstance.AssetsPolicyPolicyIdGet(policyId, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoAssetsApi.AssetsPolicyPolicyIdGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **policyId** | **string**| Specific policy_id | 
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about a specific asset |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

