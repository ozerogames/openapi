# Org.OpenAPITools.Model.NetworkStake

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Live** | **string** | Current live stake in Lovelaces | 
**Active** | **string** | Current active stake in Lovelaces | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

