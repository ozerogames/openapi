# Org.OpenAPITools.Model.InlineResponse2003

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name of the file | 
**IpfsHash** | **string** | IPFS hash of the file | 
**Size** | **string** | IPFS node size in Bytes | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

