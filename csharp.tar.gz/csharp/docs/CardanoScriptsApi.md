# Org.OpenAPITools.Api.CardanoScriptsApi

All URIs are relative to *https://cardano-mainnet.blockfrost.io/api/v0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ScriptsDatumDatumHashGet**](CardanoScriptsApi.md#scriptsdatumdatumhashget) | **GET** /scripts/datum/{datum_hash} | Datum value
[**ScriptsGet**](CardanoScriptsApi.md#scriptsget) | **GET** /scripts | Scripts
[**ScriptsScriptHashCborGet**](CardanoScriptsApi.md#scriptsscripthashcborget) | **GET** /scripts/{script_hash}/cbor | Script CBOR
[**ScriptsScriptHashGet**](CardanoScriptsApi.md#scriptsscripthashget) | **GET** /scripts/{script_hash} | Specific script
[**ScriptsScriptHashJsonGet**](CardanoScriptsApi.md#scriptsscripthashjsonget) | **GET** /scripts/{script_hash}/json | Script JSON
[**ScriptsScriptHashRedeemersGet**](CardanoScriptsApi.md#scriptsscripthashredeemersget) | **GET** /scripts/{script_hash}/redeemers | Redeemers of a specific script


<a name="scriptsdatumdatumhashget"></a>
# **ScriptsDatumDatumHashGet**
> ScriptDatum ScriptsDatumDatumHashGet (string datumHash)

Datum value

Query JSON value of a datum by its hash

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ScriptsDatumDatumHashGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoScriptsApi(httpClient, config, httpClientHandler);
            var datumHash = db583ad85881a96c73fbb26ab9e24d1120bb38f45385664bb9c797a2ea8d9a2d;  // string | Hash of the datum

            try
            {
                // Datum value
                ScriptDatum result = apiInstance.ScriptsDatumDatumHashGet(datumHash);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoScriptsApi.ScriptsDatumDatumHashGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **datumHash** | **string**| Hash of the datum | 

### Return type

[**ScriptDatum**](ScriptDatum.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the datum value |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="scriptsget"></a>
# **ScriptsGet**
> List&lt;Object&gt; ScriptsGet (int? count = null, int? page = null, string order = null)

Scripts

List of scripts.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ScriptsGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoScriptsApi(httpClient, config, httpClientHandler);
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Scripts
                List<Object> result = apiInstance.ScriptsGet(count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoScriptsApi.ScriptsGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return list of scripts |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="scriptsscripthashcborget"></a>
# **ScriptsScriptHashCborGet**
> ScriptCbor ScriptsScriptHashCborGet (string scriptHash)

Script CBOR

CBOR representation of a `plutus` script

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ScriptsScriptHashCborGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoScriptsApi(httpClient, config, httpClientHandler);
            var scriptHash = e1457a0c47dfb7a2f6b8fbb059bdceab163c05d34f195b87b9f2b30e;  // string | Hash of the script

            try
            {
                // Script CBOR
                ScriptCbor result = apiInstance.ScriptsScriptHashCborGet(scriptHash);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoScriptsApi.ScriptsScriptHashCborGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scriptHash** | **string**| Hash of the script | 

### Return type

[**ScriptCbor**](ScriptCbor.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the CBOR representation of a &#x60;plutus&#x60; script |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="scriptsscripthashget"></a>
# **ScriptsScriptHashGet**
> Script ScriptsScriptHashGet (string scriptHash)

Specific script

Information about a specific script

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ScriptsScriptHashGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoScriptsApi(httpClient, config, httpClientHandler);
            var scriptHash = e1457a0c47dfb7a2f6b8fbb059bdceab163c05d34f195b87b9f2b30e;  // string | Hash of the script

            try
            {
                // Specific script
                Script result = apiInstance.ScriptsScriptHashGet(scriptHash);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoScriptsApi.ScriptsScriptHashGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scriptHash** | **string**| Hash of the script | 

### Return type

[**Script**](Script.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about a specific script |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="scriptsscripthashjsonget"></a>
# **ScriptsScriptHashJsonGet**
> ScriptJson ScriptsScriptHashJsonGet (string scriptHash)

Script JSON

JSON representation of a `timelock` script

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ScriptsScriptHashJsonGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoScriptsApi(httpClient, config, httpClientHandler);
            var scriptHash = e1457a0c47dfb7a2f6b8fbb059bdceab163c05d34f195b87b9f2b30e;  // string | Hash of the script

            try
            {
                // Script JSON
                ScriptJson result = apiInstance.ScriptsScriptHashJsonGet(scriptHash);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoScriptsApi.ScriptsScriptHashJsonGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scriptHash** | **string**| Hash of the script | 

### Return type

[**ScriptJson**](ScriptJson.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the JSON representation of a &#x60;timelock&#x60; script |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="scriptsscripthashredeemersget"></a>
# **ScriptsScriptHashRedeemersGet**
> List&lt;Object&gt; ScriptsScriptHashRedeemersGet (string scriptHash, int? count = null, int? page = null, string order = null)

Redeemers of a specific script

List of redeemers of a specific script

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class ScriptsScriptHashRedeemersGetExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://cardano-mainnet.blockfrost.io/api/v0";
            // Configure API key authorization: ApiKeyAuth
            config.AddApiKey("project_id", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("project_id", "Bearer");

            // create instances of HttpClient, HttpClientHandler to be reused later with different Api classes
            HttpClient httpClient = new HttpClient();
            HttpClientHandler httpClientHandler = new HttpClientHandler();
            var apiInstance = new CardanoScriptsApi(httpClient, config, httpClientHandler);
            var scriptHash = e1457a0c47dfb7a2f6b8fbb059bdceab163c05d34f195b87b9f2b30e;  // string | Hash of the script
            var count = 100;  // int? | The number of results displayed on one page. (optional)  (default to 100)
            var page = 1;  // int? | The page number for listing the results. (optional)  (default to 1)
            var order = "asc";  // string | The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  (optional)  (default to asc)

            try
            {
                // Redeemers of a specific script
                List<Object> result = apiInstance.ScriptsScriptHashRedeemersGet(scriptHash, count, page, order);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling CardanoScriptsApi.ScriptsScriptHashRedeemersGet: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scriptHash** | **string**| Hash of the script | 
 **count** | **int?**| The number of results displayed on one page. | [optional] [default to 100]
 **page** | **int?**| The page number for listing the results. | [optional] [default to 1]
 **order** | **string**| The ordering of items from the point of view of the blockchain, not the page listing itself. By default, we return oldest first, newest last.  | [optional] [default to asc]

### Return type

**List<Object>**

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Return the information about redeemers of a specific script |  -  |
| **400** | Bad request |  -  |
| **403** | Authentication secret is missing or invalid |  -  |
| **404** | Component not found |  -  |
| **418** | IP has been auto-banned for extensive sending of requests after usage limit has been reached |  -  |
| **429** | Usage limit reached |  -  |
| **500** | Internal Server Error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

