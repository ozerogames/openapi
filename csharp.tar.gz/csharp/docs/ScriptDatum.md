# Org.OpenAPITools.Model.ScriptDatum

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**JsonValue** | **string** | JSON content of the datum | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

