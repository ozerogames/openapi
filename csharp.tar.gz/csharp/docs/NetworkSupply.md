# Org.OpenAPITools.Model.NetworkSupply

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Max** | **string** | Maximum supply in Lovelaces | 
**Total** | **string** | Current total (max supply - reserves) supply in Lovelaces | 
**Circulating** | **string** | Current circulating (UTXOs + withdrawables) supply in Lovelaces | 
**Locked** | **string** | Current supply locked by scripts in Lovelaces | 
**Treasury** | **string** | Current supply locked in treasury | 
**Reserves** | **string** | Current supply locked in reserves | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

