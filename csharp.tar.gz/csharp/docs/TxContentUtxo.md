# Org.OpenAPITools.Model.TxContentUtxo

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Hash** | **string** | Transaction hash | 
**Inputs** | [**List&lt;TxContentUtxoInputs&gt;**](TxContentUtxoInputs.md) |  | 
**Outputs** | [**List&lt;TxContentUtxoOutputs&gt;**](TxContentUtxoOutputs.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

