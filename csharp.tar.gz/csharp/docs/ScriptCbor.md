# Org.OpenAPITools.Model.ScriptCbor

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cbor** | [**AnyOfstringobjectarrayintegernumberboolean**](AnyOfstringobjectarrayintegernumberboolean.md) | CBOR contents of the &#x60;plutus&#x60; script, null for &#x60;timelocks&#x60; | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

