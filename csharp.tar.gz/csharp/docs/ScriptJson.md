# Org.OpenAPITools.Model.ScriptJson

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Json** | [**AnyOfstringobjectarrayintegernumberboolean**](AnyOfstringobjectarrayintegernumberboolean.md) | JSON contents of the &#x60;timelock&#x60; script, null for &#x60;plutus&#x60; scripts | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

