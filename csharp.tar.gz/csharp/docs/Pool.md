# Org.OpenAPITools.Model.Pool

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PoolId** | **string** | Bech32 pool ID | 
**Hex** | **string** | Hexadecimal pool ID. | 
**VrfKey** | **string** | VRF key hash | 
**BlocksMinted** | **int** | Total minted blocks | 
**BlocksEpoch** | **int** | Number of blocks minted in the current epoch | 
**LiveStake** | **string** |  | 
**LiveSize** | **decimal** |  | 
**LiveSaturation** | **decimal** |  | 
**LiveDelegators** | **decimal** |  | 
**ActiveStake** | **string** |  | 
**ActiveSize** | **decimal** |  | 
**DeclaredPledge** | **string** | Stake pool certificate pledge | 
**LivePledge** | **string** | Stake pool current pledge | 
**MarginCost** | **decimal** | Margin tax cost of the stake pool | 
**FixedCost** | **string** | Fixed tax cost of the stake pool | 
**RewardAccount** | **string** | Bech32 reward account of the stake pool | 
**Owners** | **List&lt;string&gt;** |  | 
**Registration** | **List&lt;string&gt;** |  | 
**Retirement** | **List&lt;string&gt;** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

