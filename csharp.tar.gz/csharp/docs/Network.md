# Org.OpenAPITools.Model.Network

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Supply** | [**NetworkSupply**](NetworkSupply.md) |  | 
**Stake** | [**NetworkStake**](NetworkStake.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

